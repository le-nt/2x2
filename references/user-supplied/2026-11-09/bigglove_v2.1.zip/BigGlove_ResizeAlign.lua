local _bigGloveEnvironment = {}
setmetatable(_bigGloveEnvironment, {__index = getfenv(1)})
setfenv(1, _bigGloveEnvironment)

local PLUGIN_NAME = "ProtoAno's BigGlove - ResizeAlign"
local TOOLBAR_NAME = "ProtoAno's BigGlove"

-- Theme Editor (i guess)
local GUI_BACKGROUND_HEX = "#8DB83E"
local GUI_BORDER_HEX = "#737373"
local GUI_TEXT_HEX = "#FFFFFF"

local TOOL_PANEL_SIZE = UDim2.new(0, 236, 0, 262)
local ADVANCED_PANEL_SIZE = UDim2.new(0, 360, 0, 326)
local ACKNOWLEDGMENT_PANEL_SIZE = UDim2.new(0, 320, 0, 208)

plugin = PluginManager():CreatePlugin()

local Selection = game:GetService("Selection")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local CoreGui = game:GetService("CoreGui")

local toolbar = plugin:CreateToolbar(TOOLBAR_NAME)
local showButton = toolbar:CreateButton("Resize", "Show " .. PLUGIN_NAME, "bigglove_resizealign.png")

local activeMode = nil
local dragging = false
local pluginMouseActive = false
local collectiveMovement = false
local symmetricResize = false
local globalRotation = false
local activeTab = "advanced"
local activeBuildTool = "resizeAlign"
local originals = {}
local moveReferenceCFrame = nil
local activeParts = {}
local moveHandles = nil
local moveProxy = nil
local resizeHandles = nil
local rotateHandles = nil
local rotateProxy = nil
local rotateReferenceCFrame = nil
local gui = nil
local panel = nil
local acknowledgmentPanel = nil
local toolButtons = {}
local tabButtons = {}
local buildToolButtons = {}
local buildToolPages = {}
local incrementBoxes = {}
local checkboxButtons = {}
local setPanelVisible = nil
local refreshButtonStates = nil
local refreshCurrentHandles = nil
local finishDrag = nil
local clearHandles = nil
local basicPage = nil
local advancedPage = nil
local buildPreviewRoots = {}
local buildPreviewPartStyles = {}
local buildPreviewCloneParents = {}
local buildPreviewSourceRoots = {}
local updateBuildPreview = nil
local clearBuildPreview = nil
local isEven = nil
local actionCountLabel = nil
local selectionRefreshTicket = 0
local selectionWatcherSignature = nil
local rotateRefreshTicket = 0
buildApplySelectionRefreshSuppressed = false

local resizeAlignSideAIndex = 1
local resizeAlignSideBIndex = 2
local resizeAlignPartA = nil
local resizeAlignPartB = nil
local resizeAlignHighlightA = nil
local resizeAlignHighlightB = nil
local resizeAlignSelectAButton = nil
local resizeAlignSelectBButton = nil
local resizeAlignIncrement = 0
local resizeAlignKeepJoints = false
local repeatModeIndex = 1
local repeatAxisIndex = 1
local repeatCount = 1
local repeatAngle = 0
local repeatOffsetX = 0
local repeatOffsetY = 0
local repeatOffsetZ = 0
local smoothAxisIndex = 1
local smoothSquaredAxis = false
local smoothFlipAxis = false
local smoothSwapSide = false
local smoothAlignmentIndex = 3
local smoothModeIndex = 1
local smoothCount = 1
local smoothAngle = 0

local increments = {
	move = 1,
	rotate = 15,
	resize = 1
}

local sideOptions = {
	{name = "Right", normal = Enum.NormalId.Right},
	{name = "Left", normal = Enum.NormalId.Left},
	{name = "Top", normal = Enum.NormalId.Top},
	{name = "Bottom", normal = Enum.NormalId.Bottom},
	{name = "Back", normal = Enum.NormalId.Back},
	{name = "Front", normal = Enum.NormalId.Front}
}

local axisOptions = {
	{name = "X", vector = Vector3.new(1, 0, 0)},
	{name = "Y", vector = Vector3.new(0, 1, 0)},
	{name = "Z", vector = Vector3.new(0, 0, 1)}
}

local repeatModeOptions = {"Continue", "Reflect"}
local smoothModeOptions = {"Linear", "Pillar", "Circular"}
local alignmentOptions = {"Inside", "Middle", "Outside"}
local BASIC_RESIZE_MIN_SIZE = 0.001
local APPLY_STAGGER_INTERVAL = 6
local APPLY_STAGGER_DELAY = 0.03

local normalVectors = {
	[Enum.NormalId.Right] = Vector3.new(1, 0, 0),
	[Enum.NormalId.Left] = Vector3.new(-1, 0, 0),
	[Enum.NormalId.Top] = Vector3.new(0, 1, 0),
	[Enum.NormalId.Bottom] = Vector3.new(0, -1, 0),
	[Enum.NormalId.Back] = Vector3.new(0, 0, 1),
	[Enum.NormalId.Front] = Vector3.new(0, 0, -1)
}

local axisVectors = {
	[Enum.Axis.X] = Vector3.new(1, 0, 0),
	[Enum.Axis.Y] = Vector3.new(0, 1, 0),
	[Enum.Axis.Z] = Vector3.new(0, 0, 1)
}

function roundToStep(value, step)
	if step == 0 then
		return value
	end
	if value >= 0 then
		return math.floor((value / step) + 0.5) * step
	end
	return math.ceil((value / step) - 0.5) * step
end

function isEven(value)
	return value / 2 == math.floor(value / 2)
end

function clamp(value, low, high)
	if value < low then
		return low
	end
	if value > high then
		return high
	end
	return value
end

function colorFromHex(hex)
	hex = string.gsub(hex, "#", "")
	return Color3.new(
		tonumber(string.sub(hex, 1, 2), 16) / 255,
		tonumber(string.sub(hex, 3, 4), 16) / 255,
		tonumber(string.sub(hex, 5, 6), 16) / 255
	)
end

function collectParts(object, parts)
	if object:IsA("BasePart") then
		table.insert(parts, object)
	end

	local children = object:GetChildren()
	for i = 1, #children do
		collectParts(children[i], parts)
	end
end

function isBuildPreviewObject(object)
	while object do
		if string.sub(object.Name, 1, 21) == "ProtoAnoBuildPreview_" then
			return true
		end
		if object.Name == "ProtoAnoResizeAlignFace" then
			return true
		end
		object = object.Parent
	end
	return false
end

function getSelectedCloneRoots()
	local roots = {}
	local selected = Selection:Get()
	for i = 1, #selected do
		if (selected[i]:IsA("BasePart") or selected[i]:IsA("Model")) and not isBuildPreviewObject(selected[i]) then
			table.insert(roots, selected[i])
		end
	end
	return roots
end

function isAncestorOf(ancestor, object)
	object = object.Parent
	while object do
		if object == ancestor then
			return true
		end
		object = object.Parent
	end
	return false
end

function getBuildCloneRoot(object)
	if object == game.Workspace then
		return nil
	end
	if object:IsA("Model") then
		return object
	end
	if object:IsA("BasePart") then
		return object
	end

	return nil
end

function insertUniqueBuildCloneRoot(roots, root)
	if not root then
		return
	end

	local i = 1
	while i <= #roots do
		if roots[i] == root or isAncestorOf(roots[i], root) then
			return
		elseif isAncestorOf(root, roots[i]) then
			table.remove(roots, i)
		else
			i = i + 1
		end
	end

	table.insert(roots, root)
end

function getSelectedBuildCloneRoots()
	local roots = {}
	local selected = Selection:Get()
	for i = 1, #selected do
		if selected[i].Parent and not isBuildPreviewObject(selected[i]) then
			insertUniqueBuildCloneRoot(roots, getBuildCloneRoot(selected[i]))
		end
	end
	return roots
end

function getSelectedParts()
	local parts = {}
	local roots = getSelectedCloneRoots()
	for i = 1, #roots do
		collectParts(roots[i], parts)
	end
	return parts
end

function getPrimaryPart(model)
	local ok, primaryPart = pcall(function()
		return model.PrimaryPart
	end)
	if ok and primaryPart and primaryPart:IsA("BasePart") then
		return primaryPart
	end
	return nil
end

function getPartsCenter(parts)
	if #parts == 0 then
		return Vector3.new(0, 0, 0)
	end

	local total = Vector3.new(0, 0, 0)
	for i = 1, #parts do
		total = total + parts[i].CFrame.p
	end
	return total / #parts
end

function getCollectiveMoveReferenceCFrame()
	local roots = getSelectedCloneRoots()
	if #roots == 1 then
		if roots[1]:IsA("BasePart") then
			return roots[1].CFrame
		elseif roots[1]:IsA("Model") then
			local primaryPart = getPrimaryPart(roots[1])
			if primaryPart then
				return primaryPart.CFrame
			end
			local parts = {}
			collectParts(roots[1], parts)
			return CFrame.new(getPartsCenter(parts))
		end
	end

	local parts = {}
	for i = 1, #roots do
		if roots[i]:IsA("BasePart") then
			table.insert(parts, roots[i])
		elseif roots[i]:IsA("Model") then
			local primaryPart = getPrimaryPart(roots[i])
			if primaryPart then
				table.insert(parts, primaryPart)
			else
				collectParts(roots[i], parts)
			end
		end
	end

	if #parts == 1 then
		return parts[1].CFrame
	end
	return CFrame.new(getPartsCenter(parts))
end

function getAdornee()
	activeParts = getSelectedParts()
	if #activeParts > 0 then
		return activeParts[1]
	end
	return nil
end

function rememberOriginals()
	originals = {}
	activeParts = getSelectedParts()
	if #activeParts == 0 then
		activeParts = getPartsToReselect()
	end

	for i = 1, #activeParts do
		originals[activeParts[i]] = {
			cframe = activeParts[i].CFrame,
			size = activeParts[i].Size
		}
	end
end

function hasBasicTransformTargets()
	for part, original in pairs(originals) do
		if part and part.Parent and original then
			return true
		end
	end
	return false
end

function clearBasicTransformState()
	originals = {}
end

function prepareBasicResizePartsForFreeSize()
	for part in pairs(originals) do
		pcall(function()
			part.FormFactor = Enum.FormFactor.Custom
		end)
	end
end

function localVectorToWorld(cframe, vector)
	local ok, result = pcall(function()
		return cframe:vectorToWorldSpace(vector)
	end)
	if ok then
		return result
	end
	return vector
end

function worldVectorToLocal(cframe, vector)
	local ok, result = pcall(function()
		return cframe:vectorToObjectSpace(vector)
	end)
	if ok then
		return result
	end
	return vector
end

function inverseCFrame(cframe)
	local ok, result = pcall(function()
		return cframe:inverse()
	end)
	if ok then
		return result
	end
	ok, result = pcall(function()
		return cframe:Inverse()
	end)
	if ok then
		return result
	end
	return cframe
end

function unitVector(vector)
	local magnitude = vector.magnitude
	if magnitude == 0 then
		return Vector3.new(1, 0, 0)
	end
	return vector / magnitude
end

function crossVector(first, second)
	local ok, result = pcall(function()
		return first:Cross(second)
	end)
	if ok then
		return result
	end
	ok, result = pcall(function()
		return first:cross(second)
	end)
	if ok then
		return result
	end
	return Vector3.new(
		first.y * second.z - first.z * second.y,
		first.z * second.x - first.x * second.z,
		first.x * second.y - first.y * second.x
	)
end

function dotVector(first, second)
	local ok, result = pcall(function()
		return first:Dot(second)
	end)
	if ok then
		return result
	end
	ok, result = pcall(function()
		return first:dot(second)
	end)
	if ok then
		return result
	end
	return first.x * second.x + first.y * second.y + first.z * second.z
end

function getAxisWithAngle(axisIndex, angleDegrees)
	local base = axisOptions[axisIndex].vector
	local radians = math.rad(angleDegrees)
	if axisIndex == 2 then
		return unitVector(Vector3.new(
			base.x * math.cos(radians) - base.y * math.sin(radians),
			base.x * math.sin(radians) + base.y * math.cos(radians),
			base.z
		))
	end
	return unitVector(Vector3.new(
		base.x * math.cos(radians) + base.z * math.sin(radians),
		base.y,
		-base.x * math.sin(radians) + base.z * math.cos(radians)
	))
end

function extentAlongAxis(part, axis)
	local localAxis = worldVectorToLocal(part.CFrame, axis)
	return (
		math.abs(localAxis.x) * part.Size.x +
		math.abs(localAxis.y) * part.Size.y +
		math.abs(localAxis.z) * part.Size.z
	) / 2
end

function getPartsBounds(parts, axis)
	local low = nil
	local high = nil
	for i = 1, #parts do
		local part = parts[i]
		local center = dotVector(part.CFrame.p, axis)
		local extent = extentAlongAxis(part, axis)
		local partLow = center - extent
		local partHigh = center + extent
		if not low or partLow < low then
			low = partLow
		end
		if not high or partHigh > high then
			high = partHigh
		end
	end
	if not low then
		return 0, 0
	end
	return low, high
end

function offsetObject(object, offset)
	local parts = {}
	collectParts(object, parts)
	for i = 1, #parts do
		parts[i].CFrame = parts[i].CFrame + offset
	end
end

function cloneSelectionRoots(roots)
	local clones = {}
	for i = 1, #roots do
		local ok, clone = pcall(function()
			return roots[i]:Clone()
		end)
		if ok and clone then
			clone.Parent = roots[i].Parent
			table.insert(clones, clone)
		end
	end
	return clones
end

function cloneSelectionRootsInto(roots, parent)
	local clones = {}
	local cloneRoots = {}
	for i = 1, #roots do
		local ok, clone = pcall(function()
			return roots[i]:Clone()
		end)
		if ok and clone then
			clone.Parent = parent
			table.insert(clones, clone)
			table.insert(cloneRoots, roots[i])
		end
	end
	return clones, cloneRoots
end

function cloneSelectionRootsToSourceParents(roots)
	local clones = {}
	local cloneRoots = {}
	for i = 1, #roots do
		local ok, clone = pcall(function()
			return roots[i]:Clone()
		end)
		if ok and clone then
			local parent = roots[i].Parent
			if not parent then
				parent = game.Workspace
			end
			clone.Parent = parent
			table.insert(clones, clone)
			table.insert(cloneRoots, roots[i])
		end
	end
	return clones, cloneRoots
end

function countInstances(object)
	local total = 1
	local children = object:GetChildren()
	for i = 1, #children do
		total = total + countInstances(children[i])
	end
	return total
end

function countInstancesInRoots(roots)
	local total = 0
	for i = 1, #roots do
		total = total + countInstances(roots[i])
	end
	return total
end

function partsFromRoots(roots)
	local parts = {}
	for i = 1, #roots do
		collectParts(roots[i], parts)
	end
	return parts
end

function setSelectionToClones(clones)
	if #clones > 0 then
		pcall(function()
			Selection:Set(clones)
		end)
	end
end

function selectAppliedClones(clones)
	setSelectionToClones(clones)
end

function hasLooseSmoothCloneRoots(roots)
	for i = 1, #roots do
		if not roots[i]:IsA("Model") and (not roots[i].Parent or not roots[i].Parent:IsA("Model")) then
			return true
		end
	end
	return false
end

function makeSmoothCloneFolder()
	local ok, folder = pcall(function()
		return Instance.new("Folder")
	end)
	if ok and folder then
		return folder
	end
	return Instance.new("Model")
end

function getSmoothCloneOutputParent(roots)
	local outputParent = nil
	for i = 1, #roots do
		local rootParent = roots[i].Parent
		if not rootParent then
			rootParent = game.Workspace
		end
		if not outputParent then
			outputParent = rootParent
		elseif outputParent ~= rootParent then
			return game.Workspace
		end
	end
	return outputParent or game.Workspace
end

function shouldSmoothCloneWrapInModel(roots)
	for i = 1, #roots do
		if roots[i]:IsA("Model") then
			return true
		end
		local parts = {}
		collectParts(roots[i], parts)
		if #parts ~= 1 then
			return true
		end
	end
	return false
end

function makeSmoothCloneIterationModel(iteration, parent)
	local model = Instance.new("Model")
	model.Name = "SmoothClone " .. tostring(iteration)
	model.Parent = parent
	return model
end

function stripScripts(object)
	local children = object:GetChildren()
	for i = 1, #children do
		if children[i]:IsA("Script") or children[i]:IsA("LocalScript") then
			children[i]:Remove()
		else
			stripScripts(children[i])
		end
	end
end

function clearBuildPreviewDescendants(object)
	local children = object:GetChildren()
	for i = 1, #children do
		if string.sub(children[i].Name, 1, 21) == "ProtoAnoBuildPreview_" then
			pcall(function()
				children[i].Parent = nil
				children[i]:Remove()
			end)
		else
			clearBuildPreviewDescendants(children[i])
		end
	end
end

function clearBuildPreviewSelection()
	local selected = Selection:Get()
	local kept = {}
	local changed = false
	for i = 1, #selected do
		if isBuildPreviewObject(selected[i]) then
			changed = true
		else
			table.insert(kept, selected[i])
		end
	end
	if changed then
		if #kept == 0 then
			for i = 1, #buildPreviewSourceRoots do
				if buildPreviewSourceRoots[i] and buildPreviewSourceRoots[i].Parent then
					table.insert(kept, buildPreviewSourceRoots[i])
				end
			end
		end
		pcall(function()
			Selection:Set(kept)
		end)
	end
end

function clearBuildPreview()
	clearBuildPreviewSelection()
	for i = 1, #buildPreviewRoots do
		pcall(function()
			buildPreviewRoots[i].Parent = nil
			buildPreviewRoots[i]:Remove()
		end)
	end
	clearBuildPreviewDescendants(game)
	buildPreviewRoots = {}
	buildPreviewPartStyles = {}
	buildPreviewCloneParents = {}
	buildPreviewSourceRoots = {}
end

function setArchivableRecursive(object, archivable)
	pcall(function()
		object.Archivable = archivable
	end)
	local children = object:GetChildren()
	for i = 1, #children do
		setArchivableRecursive(children[i], archivable)
	end
end

function rememberBuildPreviewPartStyle(part)
	if not buildPreviewPartStyles[part] then
		buildPreviewPartStyles[part] = {
			canCollide = part.CanCollide,
			locked = part.Locked,
			transparency = part.Transparency
		}
	end
end

function styleBuildPreviewObject(object)
	if object:IsA("Script") or object:IsA("LocalScript") then
		object:Remove()
		return
	end

	setArchivableRecursive(object, false)
	local parts = {}
	collectParts(object, parts)
	for i = 1, #parts do
		rememberBuildPreviewPartStyle(parts[i])
		parts[i].CanCollide = false
		parts[i].Locked = true
		parts[i].Transparency = 0.55
	end

	stripScripts(object)
end

function restoreBuildPreviewObject(object)
	setArchivableRecursive(object, true)
	local parts = {}
	collectParts(object, parts)
	for i = 1, #parts do
		local style = buildPreviewPartStyles[parts[i]]
		if style then
			parts[i].CanCollide = style.canCollide
			parts[i].Locked = style.locked
			parts[i].Transparency = style.transparency
			buildPreviewPartStyles[parts[i]] = nil
		end
	end
end

function getLinearCloneSettings(axisIndex, angle, count)
	local roots = getSelectedBuildCloneRoots()
	local parts = partsFromRoots(roots)
	if #parts == 0 then
		return nil
	end

	local axis = getAxisWithAngle(axisIndex, angle)
	local low, high = getPartsBounds(parts, axis)
	local span = high - low
	if span < 0.2 then
		span = 0.2
	end

	return {
		roots = roots,
		axis = axis,
		baseAxis = axisOptions[axisIndex].vector,
		axisIndex = axisIndex,
		angle = angle,
		center = getPartsCenter(parts),
		span = span,
		count = clamp(count, 1, 100)
	}
end

function getRepeatSettings()
	local settings = getLinearCloneSettings(repeatAxisIndex, repeatAngle, repeatCount)
	if not settings then
		return nil
	end
	settings.extraOffset = Vector3.new(repeatOffsetX, repeatOffsetY, repeatOffsetZ)
	return settings
end

function getRepeatOffset(settings, iteration)
	local offset
	if repeatModeOptions[repeatModeIndex] == "Reflect" then
		local side = 1
		if isEven(iteration) then
			side = -1
		end
		offset = settings.axis * settings.span * math.ceil(iteration / 2) * side
	else
		offset = settings.axis * settings.span * iteration
	end
	return offset + (settings.extraOffset * iteration)
end

function getRepeatReflectRotation(settings)
	if settings.axisIndex == 2 then
		return CFrame.Angles(math.pi, 0, 0)
	end
	return CFrame.Angles(0, math.pi, 0)
end

function reflectPositionAcrossAxisPlane(position, axis, center)
	local fromCenter = position - center
	return position - (axis * (dotVector(fromCenter, axis) * 2))
end

function reflectObjectAcrossRepeatAxis(object, settings)
	local parts = {}
	local rotation = getRepeatReflectRotation(settings)
	collectParts(object, parts)
	for i = 1, #parts do
		local position = reflectPositionAcrossAxisPlane(parts[i].CFrame.p, settings.axis, settings.center)
		parts[i].CFrame = CFrame.new(position) * rotation * (parts[i].CFrame - parts[i].CFrame.p)
	end
end

function transformRepeatClone(object, settings, iteration)
	if repeatModeOptions[repeatModeIndex] == "Reflect" then
		reflectObjectAcrossRepeatAxis(object, settings)
	end
	offsetObject(object, getRepeatOffset(settings, iteration))
end

function getCircularRadialAxisForAxis(axisIndex)
	if axisIndex == 2 then
		return Vector3.new(1, 0, 0)
	end
	return Vector3.new(0, 1, 0)
end

function getSmoothCircularRadialOffset(radialSpan)
	local radialHalf = radialSpan / 2
	if alignmentOptions[smoothAlignmentIndex] == "Inside" then
		return radialHalf
	elseif alignmentOptions[smoothAlignmentIndex] == "Outside" then
		return -radialHalf
	end
	return 0
end

function getSmoothCloneReferenceCFrame(roots)
	local parts = {}
	for i = 1, #roots do
		if roots[i]:IsA("BasePart") then
			table.insert(parts, roots[i])
		elseif roots[i]:IsA("Model") then
			local primaryPart = getPrimaryPart(roots[i])
			if primaryPart then
				table.insert(parts, primaryPart)
			else
				collectParts(roots[i], parts)
			end
		end
	end
	if parts[1] then
		return parts[1].CFrame
	end
	return CFrame.new()
end

function getSmoothCloneSettings()
	local axisAngle = smoothAngle
	if smoothModeOptions[smoothModeIndex] ~= "Linear" then
		axisAngle = 0
	end
	local settings = getLinearCloneSettings(smoothAxisIndex, axisAngle, smoothCount)
	if not settings then
		return nil
	end
	settings.angle = smoothAngle

	if smoothFlipAxis then
		settings.axis = settings.axis * -1
		settings.baseAxis = settings.baseAxis * -1
	end

	local alignmentOffset = 0
	if alignmentOptions[smoothAlignmentIndex] == "Inside" then
		alignmentOffset = -settings.span
	elseif alignmentOptions[smoothAlignmentIndex] == "Middle" then
		alignmentOffset = -(settings.span / 2)
	end
	if smoothSwapSide then
		alignmentOffset = alignmentOffset * -1
	end

	settings.alignmentOffset = alignmentOffset
	local parts = partsFromRoots(settings.roots)
	local referenceCFrame = getSmoothCloneReferenceCFrame(settings.roots)
	settings.rotationAxis = unitVector(localVectorToWorld(referenceCFrame, axisOptions[smoothAxisIndex].vector))
	if smoothFlipAxis then
		settings.rotationAxis = settings.rotationAxis * -1
	end
	settings.radialAxis = unitVector(localVectorToWorld(referenceCFrame, getCircularRadialAxisForAxis(settings.axisIndex)))
	if smoothSwapSide then
		settings.radialAxis = settings.radialAxis * -1
	end
	settings.tangentAxis = unitVector(crossVector(settings.rotationAxis, settings.radialAxis))
	local tangentLow, tangentHigh = getPartsBounds(parts, settings.tangentAxis)
	local radialLow, radialHigh = getPartsBounds(parts, settings.radialAxis)
	local tangentSpan = tangentHigh - tangentLow
	local radialSpan = radialHigh - radialLow
	if tangentSpan < 0.2 then
		tangentSpan = 0.2
	end
	if radialSpan < 0.2 then
		radialSpan = 0.2
	end
	settings.circularTangentHalf = tangentSpan / 2
	settings.circularRadialOffset = getSmoothCircularRadialOffset(radialSpan)
	settings.circularStepAngle = settings.angle
	if smoothFlipAxis then
		settings.circularStepAngle = settings.circularStepAngle * -1
	end
	return settings
end

function getSmoothCloneOffset(settings, iteration)
	local step = iteration
	if smoothSquaredAxis then
		step = iteration * iteration
	end
	return settings.axis * ((settings.span * step) + settings.alignmentOffset)
end

function getAxisRotationCFrame(axisIndex, radians)
	if axisIndex == 1 then
		return CFrame.Angles(radians, 0, 0)
	elseif axisIndex == 2 then
		return CFrame.Angles(0, radians, 0)
	end
	return CFrame.Angles(0, 0, radians)
end

function getVectorRotationCFrame(axis, radians)
	local ok, rotation = pcall(function()
		return CFrame.fromAxisAngle(axis, radians)
	end)
	if ok and rotation then
		return rotation
	end

	axis = unitVector(axis)
	local x = axis.x
	local y = axis.y
	local z = axis.z
	local c = math.cos(radians)
	local s = math.sin(radians)
	local t = 1 - c
	return CFrame.new(
		0, 0, 0,
		(t * x * x) + c, (t * x * y) - (s * z), (t * x * z) + (s * y),
		(t * x * y) + (s * z), (t * y * y) + c, (t * y * z) - (s * x),
		(t * x * z) - (s * y), (t * y * z) + (s * x), (t * z * z) + c
	)
end

function rotateObjectAroundPoint(object, center, rotation)
	local parts = {}
	collectParts(object, parts)
	for i = 1, #parts do
		local relative = parts[i].CFrame.p - center
		local rotatedPosition = center + localVectorToWorld(rotation, relative)
		parts[i].CFrame = CFrame.new(rotatedPosition) * rotation * (parts[i].CFrame - parts[i].CFrame.p)
	end
end

function collectPartsFromObjects(objects)
	local parts = {}
	for i = 1, #objects do
		collectParts(objects[i], parts)
	end
	return parts
end

function offsetObjects(objects, offset)
	for i = 1, #objects do
		offsetObject(objects[i], offset)
	end
end

function getObjectsCircularFrame(objects, tangentAxis, radialAxis, rotationAxis)
	local parts = collectPartsFromObjects(objects)
	local tangentLow, tangentHigh = getPartsBounds(parts, tangentAxis)
	local radialLow, radialHigh = getPartsBounds(parts, radialAxis)
	local rotationLow, rotationHigh = getPartsBounds(parts, rotationAxis)
	local tangentSpan = tangentHigh - tangentLow
	if tangentSpan < 0.2 then
		tangentSpan = 0.2
	end
	return {
		center =
			(tangentAxis * ((tangentLow + tangentHigh) / 2)) +
			(radialAxis * ((radialLow + radialHigh) / 2)) +
			(rotationAxis * ((rotationLow + rotationHigh) / 2)),
		tangentHalf = tangentSpan / 2
	}
end

function rotateObjectsAroundPoint(objects, center, rotation)
	local parts = collectPartsFromObjects(objects)
	for i = 1, #parts do
		local relative = parts[i].CFrame.p - center
		local rotatedPosition = center + localVectorToWorld(rotation, relative)
		parts[i].CFrame = CFrame.new(rotatedPosition) * rotation * (parts[i].CFrame - parts[i].CFrame.p)
	end
end

function transformCircularSmoothStep(objects, settings, tangentAxis, radialAxis, rotationAxis)
	local parts = collectPartsFromObjects(objects)
	local tangentLow, tangentHigh = getPartsBounds(parts, tangentAxis)
	local radialLow, radialHigh = getPartsBounds(parts, radialAxis)
	local rotationLow, rotationHigh = getPartsBounds(parts, rotationAxis)
	local pivot =
		(tangentAxis * tangentHigh) +
		(radialAxis * ((radialLow + radialHigh) / 2)) +
		(rotationAxis * ((rotationLow + rotationHigh) / 2))
	local rotation = getVectorRotationCFrame(rotationAxis, math.rad(settings.circularStepAngle))
	rotateObjectsAroundPoint(objects, pivot, rotation)
	local nextTangentAxis = unitVector(localVectorToWorld(rotation, tangentAxis))
	local nextRadialAxis = unitVector(localVectorToWorld(rotation, radialAxis))
	local nextRotationAxis = unitVector(localVectorToWorld(rotation, rotationAxis))
	local nextParts = collectPartsFromObjects(objects)
	local nextLow = getPartsBounds(nextParts, nextTangentAxis)
	local pivotCoord = dotVector(pivot, nextTangentAxis)
	offsetObjects(objects, nextTangentAxis * (pivotCoord - nextLow))
	return nextTangentAxis, nextRadialAxis, nextRotationAxis
end

function transformSmoothCloneObjects(objects, settings, iteration)
	if smoothModeOptions[smoothModeIndex] ~= "Circular" then
		for i = 1, #objects do
			transformSmoothClone(objects[i], settings, iteration)
		end
		return
	end

	local step = iteration
	if smoothSquaredAxis then
		step = iteration * iteration
	end
	local tangentAxis = settings.tangentAxis
	local radialAxis = settings.radialAxis
	local rotationAxis = settings.rotationAxis
	for i = 1, step do
		tangentAxis, radialAxis, rotationAxis = transformCircularSmoothStep(objects, settings, tangentAxis, radialAxis, rotationAxis)
	end
end

function transformSmoothClone(object, settings, iteration)
	local mode = smoothModeOptions[smoothModeIndex]
	if mode == "Linear" then
		offsetObject(object, getSmoothCloneOffset(settings, iteration))
	elseif mode == "Pillar" then
		offsetObject(object, getSmoothCloneOffset(settings, iteration))
		local step = iteration
		if smoothSquaredAxis then
			step = iteration * iteration
		end
		rotateObjectAroundPoint(object, settings.center, getAxisRotationCFrame(settings.axisIndex, math.rad(settings.angle * step)))
	else
		transformSmoothCloneObjects({object}, settings, iteration)
	end
end

function cloneSmoothCloneIteration(settings, iteration, outputParent, wrapInModel)
	local selected = {}
	if wrapInModel then
		local iterationModel = makeSmoothCloneIterationModel(iteration, outputParent)
		local clones = cloneSelectionRootsInto(settings.roots, iterationModel)
		if #clones == 0 then
			pcall(function()
				iterationModel:Remove()
			end)
			return selected
		end
		transformSmoothCloneObjects(clones, settings, iteration)
		table.insert(selected, iterationModel)
	else
		local clones = cloneSelectionRootsToSourceParents(settings.roots)
		transformSmoothCloneObjects(clones, settings, iteration)
		for i = 1, #clones do
			table.insert(selected, clones[i])
		end
	end
	return selected
end

function getActivePreviewSettings()
	if activeBuildTool == "repeat" then
		return "Repeat", getRepeatSettings(), getRepeatOffset
	elseif activeBuildTool == "smooth" then
		return "SmoothClone", getSmoothCloneSettings(), getSmoothCloneOffset
	end
	return nil, nil, nil
end

function getActiveBuildActionCount()
	if activeBuildTool == "resizeAlign" then
		return 0, true
	end

	local previewName, settings = getActivePreviewSettings()
	if not settings then
		return 0, false
	end

	local perIteration = countInstancesInRoots(settings.roots)
	if previewName == "SmoothClone" then
		if shouldSmoothCloneWrapInModel(settings.roots) then
			perIteration = perIteration + 1
		end
	end
	return perIteration * settings.count, true
end

function getActionSafetyText(count)
	if count <= 55 then
		return "Safe Action"
	elseif count <= 210 then
		return "Laggy Action"
	end
	return "Builder Beware: Mileage May Vary"
end

function formatActionCountText(count)
	return "Creates: " .. tostring(count) .. " instances (" .. getActionSafetyText(count) .. ")"
end

function updateActionCountLabel()
	if not actionCountLabel then
		return
	end

	if activeTab ~= "advanced" or not activeBuildTool then
		actionCountLabel.Text = formatActionCountText(0)
		return
	end

	local count, valid = getActiveBuildActionCount()
	if not valid then
		actionCountLabel.Text = "Creates: select parts/models"
	else
		actionCountLabel.Text = formatActionCountText(count)
	end
end

function updateBuildPreview()
	clearBuildPreview()
	local previewName, settings, getOffset = getActivePreviewSettings()
	updateActionCountLabel()
	if not settings then
		return
	end
	if not panel or not panel.Visible then
		return
	end
	if not advancedPage or not advancedPage.Visible then
		return
	end
	buildPreviewSourceRoots = settings.roots

	for iteration = 1, settings.count do
		local iterationModel = makeSmoothCloneIterationModel(iteration, game.Workspace)
		iterationModel.Name = "ProtoAnoBuildPreview_" .. previewName .. "_" .. tostring(iteration)
		pcall(function()
			iterationModel.Archivable = false
		end)
		table.insert(buildPreviewRoots, iterationModel)
		local clones, cloneRoots = cloneSelectionRootsInto(settings.roots, iterationModel)
		local offset = getOffset(settings, iteration)
		if #clones == 0 then
			pcall(function()
				iterationModel:Remove()
			end)
			table.remove(buildPreviewRoots, #buildPreviewRoots)
		else
			if activeBuildTool == "smooth" then
				for i = 1, #clones do
					buildPreviewCloneParents[clones[i]] = cloneRoots[i].Parent
					styleBuildPreviewObject(clones[i])
				end
				transformSmoothCloneObjects(clones, settings, iteration)
			else
				for i = 1, #clones do
					buildPreviewCloneParents[clones[i]] = cloneRoots[i].Parent
					styleBuildPreviewObject(clones[i])
					if activeBuildTool == "repeat" then
						transformRepeatClone(clones[i], settings, iteration)
					else
						offsetObject(clones[i], offset)
					end
				end
			end
		end
	end
end

function getSideName(index)
	return sideOptions[index].name
end

function getFirstSelectedResizeAlignPart()
	local selected = Selection:Get()
	local parts = {}
	for i = 1, #selected do
		if selected[i]:IsA("BasePart") and not isBuildPreviewObject(selected[i]) then
			return selected[i]
		elseif selected[i]:IsA("Model") and not isBuildPreviewObject(selected[i]) then
			parts = {}
			collectParts(selected[i], parts)
			if parts[1] then
				return parts[1]
			end
		end
	end
	return nil
end

function clearResizeAlignHighlight(highlight)
	if highlight then
		pcall(function()
			highlight:Remove()
		end)
	end
end

function clearResizeAlignHighlightDescendants(object)
	local children = object:GetChildren()
	for i = 1, #children do
		if children[i].Name == "ProtoAnoResizeAlignFace" then
			pcall(function()
				children[i]:Remove()
			end)
		else
			clearResizeAlignHighlightDescendants(children[i])
		end
	end
end

function clearResizeAlignHighlights()
	clearResizeAlignHighlight(resizeAlignHighlightA)
	clearResizeAlignHighlight(resizeAlignHighlightB)
	resizeAlignHighlightA = nil
	resizeAlignHighlightB = nil
	clearResizeAlignHighlightDescendants(game.Workspace)
end

function getResizeAlignFaceSize(part, normal)
	local pad = 0.08
	local thin = 0.06
	if math.abs(normal.x) > 0 then
		return Vector3.new(thin, part.Size.y + pad, part.Size.z + pad)
	elseif math.abs(normal.y) > 0 then
		return Vector3.new(part.Size.x + pad, thin, part.Size.z + pad)
	end
	return Vector3.new(part.Size.x + pad, part.Size.y + pad, thin)
end

function makeResizeAlignHighlight(part, sideIndex, colorName)
	if not part or not part.Parent then
		return nil
	end

	local normal = normalVectors[sideOptions[sideIndex].normal]
	local highlight = Instance.new("Part")
	highlight.Name = "ProtoAnoResizeAlignFace"
	highlight.Anchored = true
	highlight.Archivable = false
	highlight.CanCollide = false
	highlight.Locked = true
	highlight.Transparency = 0.45
	highlight.BrickColor = BrickColor.new(colorName)
	pcall(function()
		highlight.FormFactor = Enum.FormFactor.Custom
	end)
	highlight.Size = getResizeAlignFaceSize(part, normal)
	highlight.CFrame = part.CFrame + localVectorToWorld(part.CFrame, normal * ((dotVector(part.Size, Vector3.new(math.abs(normal.x), math.abs(normal.y), math.abs(normal.z))) / 2) + 0.04))
	highlight.Parent = game.Workspace
	return highlight
end

function updateResizeAlignHighlights()
	clearResizeAlignHighlights()
	if activeBuildTool ~= "resizeAlign" or not panel or not panel.Visible then
		return
	end
	resizeAlignHighlightA = makeResizeAlignHighlight(resizeAlignPartA, resizeAlignSideAIndex, "Bright yellow")
	resizeAlignHighlightB = makeResizeAlignHighlight(resizeAlignPartB, resizeAlignSideBIndex, "Bright red")
end

function updateResizeAlignSelectButtons()
	if resizeAlignSelectAButton then
		if resizeAlignPartA and resizeAlignPartA.Parent then
			resizeAlignSelectAButton.Text = "Set"
		else
			resizeAlignSelectAButton.Text = "Select"
		end
	end
	if resizeAlignSelectBButton then
		if resizeAlignPartB and resizeAlignPartB.Parent then
			resizeAlignSelectBButton.Text = "Set"
		else
			resizeAlignSelectBButton.Text = "Select"
		end
	end
end

function getAxisName(index, squared)
	if squared then
		return axisOptions[index].name .. "^2"
	end
	return axisOptions[index].name
end

function cycleIndex(value, list)
	value = value + 1
	if value > #list then
		value = 1
	end
	return value
end

function staggerApplyStep(step)
	if step > 0 and step / APPLY_STAGGER_INTERVAL == math.floor(step / APPLY_STAGGER_INTERVAL) then
		wait(APPLY_STAGGER_DELAY)
	end
end

function resizeOneSideFromOriginal(part, originalCFrame, originalSize, sideNormal, amount)
	local absNormal = Vector3.new(math.abs(sideNormal.x), math.abs(sideNormal.y), math.abs(sideNormal.z))
	local newSize = Vector3.new(
		clamp(originalSize.x + absNormal.x * amount, 0.2, 10000),
		clamp(originalSize.y + absNormal.y * amount, 0.2, 10000),
		clamp(originalSize.z + absNormal.z * amount, 0.2, 10000)
	)
	local actualDelta = newSize - originalSize
	local localCenterOffset = Vector3.new(
		sideNormal.x * actualDelta.x / 2,
		sideNormal.y * actualDelta.y / 2,
		sideNormal.z * actualDelta.z / 2
	)
	part.Size = newSize
	part.CFrame = originalCFrame + localVectorToWorld(originalCFrame, localCenterOffset)
end

function snapResizeAlignAmount(amount)
	if resizeAlignIncrement <= 0 then
		return amount
	end
	local magnitude = math.floor(math.abs(amount) / resizeAlignIncrement) * resizeAlignIncrement
	if amount < 0 then
		return -magnitude
	end
	return magnitude
end

function getLocalResizeAlignFaceOffset(part, sideNormal)
	return Vector3.new(
		sideNormal.x * part.Size.x / 2,
		sideNormal.y * part.Size.y / 2,
		sideNormal.z * part.Size.z / 2
	)
end

function getResizeAlignFaceCoordinate(part, localNormal, referenceAxis)
	local facePosition = part.CFrame.p + localVectorToWorld(part.CFrame, getLocalResizeAlignFaceOffset(part, localNormal))
	return dotVector(facePosition, referenceAxis)
end

function beginStableResizeAlign(parts)
	local states = {}
	for i = 1, #parts do
		states[i] = {
			part = parts[i],
			anchored = parts[i].Anchored,
			canCollide = parts[i].CanCollide
		}
		parts[i].Anchored = true
		parts[i].CanCollide = false
		pcall(function()
			parts[i].FormFactor = Enum.FormFactor.Custom
		end)
	end
	return states
end

function rememberResizeAlignScene(first, second)
	local allParts = {}
	local states = {}
	collectParts(game.Workspace, allParts)
	for i = 1, #allParts do
		if allParts[i] ~= first and allParts[i] ~= second and not isBuildPreviewObject(allParts[i]) then
			table.insert(states, {
				part = allParts[i],
				cframe = allParts[i].CFrame
			})
		end
	end
	return states
end

function restoreResizeAlignScene(states)
	for i = 1, #states do
		if states[i].part and states[i].part.Parent then
			states[i].part.CFrame = states[i].cframe
		end
	end
end

function breakResizeAlignJoints(parts)
	for i = 1, #parts do
		pcall(function()
			parts[i]:BreakJoints()
		end)
	end
end

function maybeBreakResizeAlignJoints(parts)
	if not resizeAlignKeepJoints then
		breakResizeAlignJoints(parts)
	end
end

function getSmoothSurface()
	local ok, surface = pcall(function()
		return Enum.SurfaceType.Smooth
	end)
	if ok then
		return surface
	end
	return nil
end

function setResizeAlignSurface(part, propertyName, surface)
	pcall(function()
		part[propertyName] = surface
	end)
end

function beginResizeAlignSurfaces(parts)
	if resizeAlignKeepJoints then
		return {}
	end
	local smooth = getSmoothSurface()
	local surfaceNames = {"TopSurface", "BottomSurface", "LeftSurface", "RightSurface", "FrontSurface", "BackSurface"}
	local states = {}
	for i = 1, #parts do
		local partState = {
			part = parts[i],
			surfaces = {}
		}
		for j = 1, #surfaceNames do
			local propertyName = surfaceNames[j]
			pcall(function()
				partState.surfaces[propertyName] = parts[i][propertyName]
			end)
			if smooth then
				setResizeAlignSurface(parts[i], propertyName, smooth)
			end
		end
		table.insert(states, partState)
	end
	return states
end

function finishResizeAlignSurfaces(states)
	for i = 1, #states do
		if states[i].part and states[i].part.Parent then
			for propertyName, surface in pairs(states[i].surfaces) do
				setResizeAlignSurface(states[i].part, propertyName, surface)
			end
		end
	end
end

function finishStableResizeAlign(states)
	for i = 1, #states do
		if states[i].part and states[i].part.Parent then
			states[i].part.Anchored = states[i].anchored
			states[i].part.CanCollide = states[i].canCollide
		end
	end
end

function getResizeAlignApplyParts()
	if resizeAlignPartA and resizeAlignPartA.Parent and resizeAlignPartB and resizeAlignPartB.Parent then
		return resizeAlignPartA, resizeAlignPartB
	end

	local parts = getSelectedParts()
	if #parts == 2 then
		return parts[1], parts[2]
	end
	return nil, nil
end

function applyResizeAlign()
	local first, second = getResizeAlignApplyParts()
	if not first or not second or first == second then
		return
	end

	local firstLocalNormal = normalVectors[sideOptions[resizeAlignSideAIndex].normal]
	local secondLocalNormal = normalVectors[sideOptions[resizeAlignSideBIndex].normal]
	local firstWorldNormal = unitVector(localVectorToWorld(first.CFrame, firstLocalNormal))
	local secondWorldNormal = unitVector(localVectorToWorld(second.CFrame, secondLocalNormal))
	local opposition = dotVector(firstWorldNormal, secondWorldNormal)

	if opposition > -0.35 then
		return
	end

	local firstOriginalCFrame = first.CFrame
	local firstOriginalSize = first.Size
	local secondOriginalCFrame = second.CFrame
	local secondOriginalSize = second.Size
	local firstFace = getResizeAlignFaceCoordinate(first, firstLocalNormal, firstWorldNormal)
	local secondFace = getResizeAlignFaceCoordinate(second, secondLocalNormal, firstWorldNormal)
	local meetAt = (firstFace + secondFace) / 2
	local firstAmount = snapResizeAlignAmount(meetAt - firstFace)
	local secondAmount = snapResizeAlignAmount((meetAt - secondFace) / opposition)

	local sceneStates = rememberResizeAlignScene(first, second)
	local stableStates = beginStableResizeAlign({first, second})
	local surfaceStates = beginResizeAlignSurfaces({first, second})
	local ok = pcall(function()
		maybeBreakResizeAlignJoints({first, second})
		resizeOneSideFromOriginal(first, firstOriginalCFrame, firstOriginalSize, firstLocalNormal, firstAmount)
		resizeOneSideFromOriginal(second, secondOriginalCFrame, secondOriginalSize, secondLocalNormal, secondAmount)
		maybeBreakResizeAlignJoints({first, second})
	end)
	finishResizeAlignSurfaces(surfaceStates)
	finishStableResizeAlign(stableStates)
	maybeBreakResizeAlignJoints({first, second})
	restoreResizeAlignScene(sceneStates)
	if not ok then
		return
	end
	clearResizeAlignHighlights()
	ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " ResizeAlign")
	refreshCurrentHandles({first, second})
	updateResizeAlignHighlights()
end

function prepareBuildApplySelection()
	clearBuildPreview()
	wait()
	wait(0.03)
end

function applyRepeat()
	prepareBuildApplySelection()
	local settings = getRepeatSettings()
	if not settings then
		return
	end

	local allClones = {}
	for iteration = 1, settings.count do
		local clones = cloneSelectionRoots(settings.roots)
		for i = 1, #clones do
			transformRepeatClone(clones[i], settings, iteration)
			table.insert(allClones, clones[i])
		end
		staggerApplyStep(iteration)
	end

	ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " Repeat")
	selectAppliedClones(allClones)
end

function applySmoothClone()
	prepareBuildApplySelection()
	local settings = getSmoothCloneSettings()
	if not settings then
		return
	end

	local allClones = {}
	local outputParent = getSmoothCloneOutputParent(settings.roots)
	local wrapInModel = shouldSmoothCloneWrapInModel(settings.roots)
	for iteration = 1, settings.count do
		local selected = cloneSmoothCloneIteration(settings, iteration, outputParent, wrapInModel)
		for i = 1, #selected do
			table.insert(allClones, selected[i])
		end
		staggerApplyStep(iteration)
	end

	ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " SmoothClone")
	selectAppliedClones(allClones)
end

function saveIncrement(key)
	local box = incrementBoxes[key]
	if box then
		local value = tonumber(box.Text)
		if value then
			if key == "resize" then
				if value < 0 then
					value = increments[key]
				end
				increments[key] = value
			elseif value > 0 then
				increments[key] = value
			end
		end
		box.Text = tostring(increments[key])
	end
end

function saveAllIncrements()
	saveIncrement("move")
	saveIncrement("rotate")
	saveIncrement("resize")
end

function restoreSelection(parts)
	if parts and #parts > 0 then
		pcall(function()
			Selection:Set(parts)
		end)
	end
end

function clearSelection()
	pcall(function()
		Selection:Set({})
	end)
	activeParts = {}
end

function getPartsToReselect()
	local partsToReselect = getSelectedParts()
	if #partsToReselect == 0 then
		partsToReselect = activeParts
	end
	return partsToReselect
end

function setTabButtonActive(button, active)
	if active then
		button.BackgroundColor3 = Color3.new(0.26, 0.42, 0.16)
	else
		button.BackgroundColor3 = Color3.new(0.14, 0.14, 0.14)
	end
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
end

function setButtonActive(button, active)
	if active then
		button.BackgroundColor3 = Color3.new(0.18, 0.36, 0.72)
		button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	else
		button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
		button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	end
end

function setBuildButtonActive(button, active)
	if active then
		button.BackgroundColor3 = Color3.new(0.24, 0.36, 0.18)
	else
		button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	end
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
end

function setCheckboxVisual(button, checked)
	if button then
		if checked then
			button.Text = "[X]"
		else
			button.Text = "[ ]"
		end
	end
end

function refreshCheckboxVisuals()
	setCheckboxVisual(checkboxButtons.globalRotation, globalRotation)
	setCheckboxVisual(checkboxButtons.symmetricResize, symmetricResize)
	setCheckboxVisual(checkboxButtons.resizeAlignKeepJoints, resizeAlignKeepJoints)
	setCheckboxVisual(checkboxButtons.smoothSquaredAxis, smoothSquaredAxis)
	setCheckboxVisual(checkboxButtons.smoothFlipAxis, smoothFlipAxis)
	setCheckboxVisual(checkboxButtons.smoothSwapSide, smoothSwapSide)
end

function refreshBuildToolStates()
	local key, button
	for key, button in pairs(buildToolButtons) do
		setBuildButtonActive(button, key == activeBuildTool)
	end
	for key, page in pairs(buildToolPages) do
		page.Visible = key == activeBuildTool
	end
	if activeBuildTool == "repeat" or activeBuildTool == "smooth" then
		updateBuildPreview()
	else
		clearBuildPreview()
	end
	if activeBuildTool == "resizeAlign" then
		updateResizeAlignHighlights()
	else
		clearResizeAlignHighlights()
	end
	updateActionCountLabel()
end

function clearBuildToolState()
	activeBuildTool = nil
	resizeAlignPartA = nil
	resizeAlignPartB = nil
	clearBuildPreview()
	clearResizeAlignHighlights()
	updateResizeAlignSelectButtons()
	updateActionCountLabel()
end

function refreshButtonStates()
	local key, button
	for key, button in pairs(toolButtons) do
		setButtonActive(button, key == activeMode)
	end
	for key, button in pairs(tabButtons) do
		setTabButtonActive(button, key == activeTab)
	end
	refreshCheckboxVisuals()
	refreshBuildToolStates()
	pcall(function()
		showButton:SetActive(panel and panel.Visible)
	end)
end

function completeBuildTool()
	refreshButtonStates()
end

function refreshSelectionToolState()
	if dragging then
		return
	end
	updateBuildPreview()
	updateResizeAlignHighlights()
end

function getSelectionWatcherSignature()
	local chunks = {}
	local selected = Selection:Get()
	table.insert(chunks, tostring(#selected))
	for i = 1, #selected do
		table.insert(chunks, selected[i].Name)
		if selected[i]:IsA("BasePart") then
			table.insert(chunks, tostring(selected[i].CFrame.p))
			table.insert(chunks, tostring(selected[i].Size))
		elseif selected[i]:IsA("Model") then
			local parts = {}
			collectParts(selected[i], parts)
			table.insert(chunks, tostring(#parts))
			for j = 1, #parts do
				table.insert(chunks, parts[j].Name)
				table.insert(chunks, tostring(parts[j].CFrame.p))
				table.insert(chunks, tostring(parts[j].Size))
			end
		end
	end
	return table.concat(chunks, "|")
end

function runAsync(callback)
	local thread = coroutine.create(callback)
	local ok, message = coroutine.resume(thread)
	if not ok then
		print(PLUGIN_NAME .. " async error: " .. tostring(message))
	end
	return ok, message
end

function scheduleSelectionToolRefresh()
	if buildApplySelectionRefreshSuppressed then
		selectionWatcherSignature = getSelectionWatcherSignature()
		return
	end
	selectionRefreshTicket = selectionRefreshTicket + 1
	selectionWatcherSignature = getSelectionWatcherSignature()
	local ticket = selectionRefreshTicket
	refreshSelectionToolState()
	runAsync(function()
		wait()
		if ticket ~= selectionRefreshTicket then
			return
		end
		refreshSelectionToolState()
		wait(0.08)
		if ticket ~= selectionRefreshTicket then
			return
		end
		refreshSelectionToolState()
	end)
end

function refreshCurrentHandles(partsToReselect)
	restoreSelection(partsToReselect)
	scheduleSelectionToolRefresh()
	refreshButtonStates()
end

function forceRotateHandleRefresh()
	rotateRefreshTicket = rotateRefreshTicket + 1
end

function startSelectionWatcher()
	selectionWatcherSignature = getSelectionWatcherSignature()
	runAsync(function()
		while true do
			wait(0.15)
			if panel and panel.Visible and not dragging then
				local signature = getSelectionWatcherSignature()
				if signature ~= selectionWatcherSignature then
					selectionWatcherSignature = signature
					scheduleSelectionToolRefresh()
				end
			end
		end
	end)
end

function hideTools()
	setPanelVisible(false)
end

function setPanelVisible(visible)
	if panel then
		panel.Visible = visible
	end
	if visible then
		updateResizeAlignHighlights()
	else
		clearBuildPreview()
		clearResizeAlignHighlights()
	end
	refreshButtonStates()
end

function togglePanelFromToolbar()
	if panel then
		setPanelVisible(not panel.Visible)
	else
		setPanelVisible(true)
	end
end

function makeText(parent, text, x, y, w, h)
	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.BorderSizePixel = 0
	label.Font = Enum.Font.Arial
	label.FontSize = Enum.FontSize.Size12
	label.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Text = text
	label.Position = UDim2.new(0, x, 0, y)
	label.Size = UDim2.new(0, w, 0, h)
	label.Parent = parent
	return label
end

function makeSmallButton(parent, text, x, y, w, h)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = text
	button.Position = UDim2.new(0, x, 0, y)
	button.Size = UDim2.new(0, w, 0, h)
	button.Parent = parent
	return button
end

function makePage(parent, name, x, y, visible)
	local page = Instance.new("Frame")
	page.Name = name
	page.BackgroundTransparency = 1
	page.BorderSizePixel = 0
	page.Position = UDim2.new(0, x, 0, y)
	page.Size = UDim2.new(1, -x, 1, -y)
	page.Visible = visible
	page.Parent = parent
	return page
end

function makeApplyButton(parent, y, onApply)
	local button = makeSmallButton(parent, "Apply", 8, y, 74, 24)
	button.MouseButton1Click:connect(function()
		local ok = runAsync(function()
			buildApplySelectionRefreshSuppressed = true
			onApply()
			buildApplySelectionRefreshSuppressed = false
			refreshButtonStates()
			scheduleSelectionToolRefresh()
		end)
		if not ok then
			buildApplySelectionRefreshSuppressed = false
			refreshButtonStates()
			scheduleSelectionToolRefresh()
		end
	end)
	return button
end

function makeCycleButton(parent, text, x, y, w, getText, onCycle)
	makeText(parent, text, x, y + 2, 70, 18)
	local button = makeSmallButton(parent, getText(), x + 74, y, w, 22)
	button.MouseButton1Click:connect(function()
		onCycle()
		button.Text = getText()
	end)
	return button
end

function makeNumberBox(parent, label, x, y, value, onChanged)
	makeText(parent, label, x, y + 2, 70, 18)
	local box = Instance.new("TextBox")
	box.BackgroundColor3 = Color3.new(0.08, 0.08, 0.08)
	box.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	box.ClearTextOnFocus = false
	box.Font = Enum.Font.ArialBold
	box.FontSize = Enum.FontSize.Size12
	box.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	box.Text = tostring(value)
	box.Position = UDim2.new(0, x + 74, 0, y)
	box.Size = UDim2.new(0, 54, 0, 22)
	box.Parent = parent
	box.FocusLost:connect(function()
		local number = tonumber(box.Text)
		number = onChanged(number)
		box.Text = tostring(number)
	end)
	return box
end

function makeBox(parent, key, x, y)
	local box = Instance.new("TextBox")
	box.BackgroundColor3 = Color3.new(0.08, 0.08, 0.08)
	box.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	box.ClearTextOnFocus = false
	box.Font = Enum.Font.ArialBold
	box.FontSize = Enum.FontSize.Size12
	box.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	box.Text = tostring(increments[key])
	box.Position = UDim2.new(0, x, 0, y)
	box.Size = UDim2.new(0, 54, 0, 22)
	box.Parent = parent
	box.FocusLost:connect(function()
		saveIncrement(key)
	end)
	incrementBoxes[key] = box
	return box
end

function makeCheckbox(parent, text, x, y, initialValue, onChanged)
	local checked = initialValue
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	if checked then
		button.Text = "[X]"
	else
		button.Text = "[ ]"
	end
	button.Position = UDim2.new(0, x, 0, y)
	button.Size = UDim2.new(0, 28, 0, 20)
	button.Parent = parent

	makeText(parent, text, x + 34, y + 1, 140, 18)

	button.MouseButton1Click:connect(function()
		checked = not checked
		pcall(function()
			onChanged(checked)
		end)
		if text == "Global Rotation" then
			checked = globalRotation
		elseif text == "Symmetric Resize" then
			checked = symmetricResize
		elseif text == "Keep Joints" then
			checked = resizeAlignKeepJoints
		elseif text == "Axis ^2" then
			checked = smoothSquaredAxis
		elseif text == "Flip Axis" then
			checked = smoothFlipAxis
		elseif text == "Swap Side" then
			checked = smoothSwapSide
		end
		if checked then
			button.Text = "[X]"
		else
			button.Text = "[ ]"
		end
	end)

	return button
end

function makeWrappedText(parent, text, x, y, w, h, color)
	local label = makeText(parent, text, x, y, w, h)
	label.TextColor3 = color
	label.TextYAlignment = Enum.TextYAlignment.Top
	label.TextWrap = true
	return label
end

function makeCloseButton(parent)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.14, 0.14, 0.14)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = "X"
	button.Position = UDim2.new(1, -24, 0, 6)
	button.Size = UDim2.new(0, 18, 0, 18)
	button.Parent = parent
	button.MouseButton1Down:connect(function()
		setPanelVisible(false)
	end)
	button.MouseButton1Click:connect(function()
		setPanelVisible(false)
	end)
	return button
end

function getResizeAlignSideA()
	return getSideName(resizeAlignSideAIndex)
end

function cycleResizeAlignSideA()
	resizeAlignSideAIndex = cycleIndex(resizeAlignSideAIndex, sideOptions)
	updateResizeAlignHighlights()
end

function getResizeAlignSideB()
	return getSideName(resizeAlignSideBIndex)
end

function cycleResizeAlignSideB()
	resizeAlignSideBIndex = cycleIndex(resizeAlignSideBIndex, sideOptions)
	updateResizeAlignHighlights()
end

function selectResizeAlignPartA()
	resizeAlignPartA = getFirstSelectedResizeAlignPart()
	updateResizeAlignSelectButtons()
	updateResizeAlignHighlights()
end

function selectResizeAlignPartB()
	resizeAlignPartB = getFirstSelectedResizeAlignPart()
	updateResizeAlignSelectButtons()
	updateResizeAlignHighlights()
end

function setResizeAlignIncrement(value)
	if not value then
		value = resizeAlignIncrement
	end
	if value < 0 then
		value = 0
	end
	if value > 0 and value < 0.2 then
		value = 0.2
	end
	resizeAlignIncrement = value
	return resizeAlignIncrement
end

function setResizeAlignKeepJoints(value)
	resizeAlignKeepJoints = value
end

function makeResizeAlignTools(parent)
	makeCycleButton(parent, "Part 1", 8, 0, 74, getResizeAlignSideA, cycleResizeAlignSideA)
	resizeAlignSelectAButton = makeSmallButton(parent, "Select", 164, 0, 58, 22)
	resizeAlignSelectAButton.MouseButton1Click:connect(selectResizeAlignPartA)
	makeCycleButton(parent, "Part 2", 8, 25, 74, getResizeAlignSideB, cycleResizeAlignSideB)
	resizeAlignSelectBButton = makeSmallButton(parent, "Select", 164, 25, 58, 22)
	resizeAlignSelectBButton.MouseButton1Click:connect(selectResizeAlignPartB)
	makeNumberBox(parent, "Increment", 8, 52, resizeAlignIncrement, setResizeAlignIncrement)
	checkboxButtons.resizeAlignKeepJoints = makeCheckbox(parent, "Keep Joints", 154, 53, resizeAlignKeepJoints, setResizeAlignKeepJoints)
	makeApplyButton(parent, 82, applyResizeAlign)
	updateResizeAlignSelectButtons()
end

function getRepeatMode()
	return repeatModeOptions[repeatModeIndex]
end

function cycleRepeatMode()
	repeatModeIndex = cycleIndex(repeatModeIndex, repeatModeOptions)
	updateBuildPreview()
end

function setRepeatCount(value)
	if not value then
		value = repeatCount
	end
	repeatCount = clamp(math.floor(value), 1, 100)
	updateBuildPreview()
	return repeatCount
end

function getRepeatAxis()
	return getAxisName(repeatAxisIndex, false)
end

function cycleRepeatAxis()
	repeatAxisIndex = cycleIndex(repeatAxisIndex, axisOptions)
	updateBuildPreview()
end

function clampAngle(value)
	return clamp(value, -360, 360)
end

function setRepeatAngle(value)
	if not value then
		value = repeatAngle
	end
	repeatAngle = clampAngle(value)
	updateBuildPreview()
	return repeatAngle
end

function setRepeatOffsetX(value)
	if not value then
		value = repeatOffsetX
	end
	repeatOffsetX = value
	updateBuildPreview()
	return repeatOffsetX
end

function setRepeatOffsetY(value)
	if not value then
		value = repeatOffsetY
	end
	repeatOffsetY = value
	updateBuildPreview()
	return repeatOffsetY
end

function setRepeatOffsetZ(value)
	if not value then
		value = repeatOffsetZ
	end
	repeatOffsetZ = value
	updateBuildPreview()
	return repeatOffsetZ
end

function makeRepeatTools(parent)
	makeCycleButton(parent, "Mode", 8, 0, 82, getRepeatMode, cycleRepeatMode)
	makeNumberBox(parent, "Count", 8, 25, repeatCount, setRepeatCount)
	makeCycleButton(parent, "Axis", 8, 50, 54, getRepeatAxis, cycleRepeatAxis)
	makeNumberBox(parent, "Angle", 8, 75, repeatAngle, setRepeatAngle)
	makeNumberBox(parent, "X Offset", 8, 102, repeatOffsetX, setRepeatOffsetX)
	makeNumberBox(parent, "Y Offset", 8, 127, repeatOffsetY, setRepeatOffsetY)
	makeNumberBox(parent, "Z Offset", 8, 152, repeatOffsetZ, setRepeatOffsetZ)
	makeApplyButton(parent, 181, applyRepeat)
end

function getSmoothAxis()
	return getAxisName(smoothAxisIndex, smoothSquaredAxis)
end

function getSmoothMode()
	return smoothModeOptions[smoothModeIndex]
end

function cycleSmoothMode()
	smoothModeIndex = cycleIndex(smoothModeIndex, smoothModeOptions)
	updateBuildPreview()
end

function cycleSmoothAxis()
	smoothAxisIndex = cycleIndex(smoothAxisIndex, axisOptions)
	updateBuildPreview()
end

function setSmoothCount(value)
	if not value then
		value = smoothCount
	end
	smoothCount = clamp(math.floor(value), 1, 100)
	updateBuildPreview()
	return smoothCount
end

function getSmoothAlignment()
	return alignmentOptions[smoothAlignmentIndex]
end

function cycleSmoothAlignment()
	smoothAlignmentIndex = cycleIndex(smoothAlignmentIndex, alignmentOptions)
	updateBuildPreview()
end

function setSmoothAngle(value)
	if not value then
		value = smoothAngle
	end
	smoothAngle = clampAngle(value)
	updateBuildPreview()
	return smoothAngle
end

function setSmoothSquaredAxis(value)
	smoothSquaredAxis = value
	updateBuildPreview()
end

function setSmoothFlipAxis(value)
	smoothFlipAxis = value
	updateBuildPreview()
end

function setSmoothSwapSide(value)
	smoothSwapSide = value
	updateBuildPreview()
end

function makeSmoothCloneTools(parent)
	makeCycleButton(parent, "Mode", 8, 0, 74, getSmoothMode, cycleSmoothMode)
	makeCycleButton(parent, "Axis", 8, 25, 54, getSmoothAxis, cycleSmoothAxis)
	makeNumberBox(parent, "Amount", 8, 50, smoothCount, setSmoothCount)
	makeCycleButton(parent, "Align", 8, 75, 74, getSmoothAlignment, cycleSmoothAlignment)
	makeNumberBox(parent, "Angle", 8, 100, smoothAngle, setSmoothAngle)
	checkboxButtons.smoothSquaredAxis = makeCheckbox(parent, "Axis ^2", 8, 127, smoothSquaredAxis, setSmoothSquaredAxis)
	checkboxButtons.smoothFlipAxis = makeCheckbox(parent, "Flip Axis", 112, 127, smoothFlipAxis, setSmoothFlipAxis)
	checkboxButtons.smoothSwapSide = makeCheckbox(parent, "Swap Side", 216, 127, smoothSwapSide, setSmoothSwapSide)
	makeApplyButton(parent, 157, applySmoothClone)
end

function makeGui()
	gui = Instance.new("ScreenGui")
	gui.Name = "ProtoAnoBigGloveResizeAlign"
	gui.Parent = CoreGui

	panel = Instance.new("Frame")
	panel.Name = "ResizeAlignTools"
	panel.BackgroundColor3 = colorFromHex(GUI_BACKGROUND_HEX)
	panel.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	panel.Position = UDim2.new(0, 12, 0, 72)
	panel.Size = UDim2.new(0, 294, 0, 172)
	panel.Visible = false
	pcall(function()
		panel.Active = true
		panel.Draggable = true
		panel.ClipsDescendants = true
	end)
	panel.Parent = gui

	local title = makeText(panel, PLUGIN_NAME, 8, 6, 248, 22)
	title.FontSize = Enum.FontSize.Size18
	makeCloseButton(panel)

	actionCountLabel = makeText(panel, formatActionCountText(0), 8, 36, 264, 16)
	actionCountLabel.FontSize = Enum.FontSize.Size12

	advancedPage = makePage(panel, "ResizeAlignOptions", 0, 58, true)
	makeResizeAlignTools(advancedPage)
end


makeGui()
refreshButtonStates()
startSelectionWatcher()

showButton.Click:connect(togglePanelFromToolbar)

if Selection.SelectionChanged then
	Selection.SelectionChanged:connect(function()
		scheduleSelectionToolRefresh()
	end)
end

plugin.Deactivation:connect(function()
	clearBuildPreview()
	clearResizeAlignHighlights()
	refreshButtonStates()
end)
