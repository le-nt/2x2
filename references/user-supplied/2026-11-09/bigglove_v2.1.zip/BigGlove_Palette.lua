local _bigGloveEnvironment = {}
setmetatable(_bigGloveEnvironment, {__index = getfenv(1)})
setfenv(1, _bigGloveEnvironment)

local PLUGIN_NAME = "ProtoAno's BigGlove - Palette"
local TOOLBAR_NAME = "ProtoAno's BigGlove"

local GUI_BACKGROUND_HEX = "#8DB83E"
local GUI_BORDER_HEX = "#737373"
local GUI_TEXT_HEX = "#FFFFFF"
local PANEL_SIZE = UDim2.new(0, 360, 0, 248)
local ROWS_PER_PAGE = 7
local MAX_BRICKCOLOR_ID = 1032

plugin = PluginManager():CreatePlugin()

local Selection = game:GetService("Selection")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local CoreGui = game:GetService("CoreGui")

local toolbar = plugin:CreateToolbar(TOOLBAR_NAME)
local showButton = toolbar:CreateButton("Paint", "Show " .. PLUGIN_NAME, "bigglove_palette.png")

local gui = nil
local panel = nil
local activeTab = "colors"
local colorPage = 1
local palettePage = 1
local brickColors = nil
local paletteRows = {}
local tabButtons = {}
local colorRows = {}
local usageRows = {}
local colorPageLabel = nil
local palettePageLabel = nil
local colorControls = {}
local paletteControls = {}
local searchBox = nil
local filteredBrickColors = nil

pcall(function()
	math.randomseed(math.floor(tick() * 100000))
end)

local function colorFromHex(hex)
	hex = string.gsub(hex, "#", "")
	return Color3.new(
		tonumber(string.sub(hex, 1, 2), 16) / 255,
		tonumber(string.sub(hex, 3, 4), 16) / 255,
		tonumber(string.sub(hex, 5, 6), 16) / 255
	)
end

local function makeText(parent, text, x, y, w, h)
	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.BorderSizePixel = 0
	label.Font = Enum.Font.Arial
	label.FontSize = Enum.FontSize.Size12
	label.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Text = text
	label.Position = UDim2.new(0, x, 0, y)
	label.Size = UDim2.new(0, w, 0, h)
	label.Parent = parent
	return label
end

local function makeButton(parent, text, x, y, w, h)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = text
	button.Position = UDim2.new(0, x, 0, y)
	button.Size = UDim2.new(0, w, 0, h)
	button.Parent = parent
	return button
end

local function setButtonActive(button, active)
	if active then
		button.BackgroundColor3 = Color3.new(0.18, 0.36, 0.72)
	else
		button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	end
end

local function collectParts(object, parts)
	if object:IsA("BasePart") then
		table.insert(parts, object)
	end

	local children = object:GetChildren()
	for i = 1, #children do
		collectParts(children[i], parts)
	end
end

local function getSelectedParts()
	local parts = {}
	local selected = Selection:Get()
	for i = 1, #selected do
		if selected[i]:IsA("BasePart") then
			table.insert(parts, selected[i])
		elseif selected[i]:IsA("Model") then
			collectParts(selected[i], parts)
		end
	end
	return parts
end

local function getPaletteScanParts()
	local parts = getSelectedParts()
	if #parts > 0 then
		return parts
	end
	collectParts(game.Workspace, parts)
	return parts
end

local function getBrickColorName(brickColor)
	local ok, name = pcall(function()
		return brickColor.Name
	end)
	if ok and name then
		return name
	end
	ok, name = pcall(function()
		return brickColor.name
	end)
	if ok and name then
		return name
	end
	return tostring(brickColor)
end

local function getBrickColorNumber(brickColor)
	local ok, number = pcall(function()
		return brickColor.Number
	end)
	if ok and number then
		return number
	end
	ok, number = pcall(function()
		return brickColor.number
	end)
	if ok and number then
		return number
	end
	return 0
end

local function getBrickColorColor(brickColor)
	local ok, color = pcall(function()
		return brickColor.Color
	end)
	if ok and color then
		return color
	end
	ok, color = pcall(function()
		return brickColor.color
	end)
	if ok and color then
		return color
	end
	return Color3.new(0, 0, 0)
end

local function makeBrickColorInfo(brickColor)
	return {
		brickColor = brickColor,
		name = getBrickColorName(brickColor),
		number = getBrickColorNumber(brickColor),
		color = getBrickColorColor(brickColor)
	}
end

local function loadBrickColors()
	if brickColors then
		return brickColors
	end

	local seen = {}
	brickColors = {}
	local function addBrickColor(brickColor, exactId)
		if brickColor then
			local number = getBrickColorNumber(brickColor)
			if (not exactId or number == exactId) and number > 0 and not seen[number] then
				seen[number] = true
				table.insert(brickColors, makeBrickColorInfo(brickColor))
			end
		end
	end

	for id = 1, MAX_BRICKCOLOR_ID do
		local ok, brickColor = pcall(function()
			return BrickColor.new(id)
		end)
		if ok and brickColor then
			addBrickColor(brickColor, id)
		end
	end

	for index = 0, 255 do
		local ok, brickColor = pcall(function()
			return BrickColor.palette(index)
		end)
		if ok and brickColor then
			addBrickColor(brickColor, nil)
		end
	end

	table.sort(brickColors, function(first, second)
		return first.number < second.number
	end)
	return brickColors
end

local function getSearchText()
	if searchBox and searchBox.Text then
		return string.lower(searchBox.Text)
	end
	return ""
end

local function getFilteredBrickColors()
	local colors = loadBrickColors()
	local searchText = getSearchText()
	if searchText == "" then
		filteredBrickColors = colors
		return filteredBrickColors
	end

	filteredBrickColors = {}
	for i = 1, #colors do
		local name = string.lower(colors[i].name)
		local number = tostring(colors[i].number)
		if string.find(name, searchText, 1, true) or string.find(number, searchText, 1, true) then
			table.insert(filteredBrickColors, colors[i])
		end
	end
	return filteredBrickColors
end

local function getMaxPage(count)
	local maxPage = math.ceil(count / ROWS_PER_PAGE)
	if maxPage < 1 then
		maxPage = 1
	end
	return maxPage
end

local refreshPalette = nil

local function paintSelection(info)
	local parts = getSelectedParts()
	if #parts == 0 then
		return
	end
	for i = 1, #parts do
		parts[i].BrickColor = info.brickColor
	end
	ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " Paint")
end

local function getRandomBrickColorInfo()
	local colors = loadBrickColors()
	if #colors == 0 then
		return nil
	end
	return colors[math.random(1, #colors)]
end

local function randomizeSelection()
	local parts = getSelectedParts()
	if #parts == 0 then
		return
	end
	for i = 1, #parts do
		local info = getRandomBrickColorInfo()
		if info then
			parts[i].BrickColor = info.brickColor
		end
	end
	ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " Randomize")
	if activeTab == "palette" then
		refreshPalette()
	end
end

local function refreshButtonStates()
	setButtonActive(tabButtons.colors, activeTab == "colors")
	setButtonActive(tabButtons.palette, activeTab == "palette")
	pcall(function()
		showButton:SetActive(panel and panel.Visible)
	end)
end

local updateColorPage = nil
local updatePalettePage = nil

local function setTab(tab)
	activeTab = tab
	for i = 1, #colorRows do
		colorRows[i].root.Visible = activeTab == "colors"
	end
	for i = 1, #usageRows do
		usageRows[i].root.Visible = activeTab == "palette"
	end
	for i = 1, #colorControls do
		colorControls[i].Visible = activeTab == "colors"
	end
	for i = 1, #paletteControls do
		paletteControls[i].Visible = activeTab == "palette"
	end
	updateColorPage()
	updatePalettePage()
	refreshButtonStates()
end

local function makeColorRow(parent, index)
	local root = Instance.new("Frame")
	root.BackgroundTransparency = 1
	root.BorderSizePixel = 0
	root.Position = UDim2.new(0, 8, 0, 58 + ((index - 1) * 22))
	root.Size = UDim2.new(0, 342, 0, 20)
	root.Parent = parent

	local swatch = makeButton(root, "", 0, 1, 18, 18)
	local label = makeButton(root, "", 26, 1, 308, 18)
	label.BackgroundTransparency = 1
	label.BorderSizePixel = 0
	label.TextXAlignment = Enum.TextXAlignment.Left
	return {root = root, swatch = swatch, label = label, info = nil}
end

local function makeUsageRow(parent, index)
	local root = Instance.new("Frame")
	root.BackgroundTransparency = 1
	root.BorderSizePixel = 0
	root.Position = UDim2.new(0, 8, 0, 58 + ((index - 1) * 22))
	root.Size = UDim2.new(0, 342, 0, 20)
	root.Visible = false
	root.Parent = parent

	local swatch = makeButton(root, "", 0, 1, 18, 18)
	local label = makeButton(root, "", 26, 1, 308, 18)
	label.BackgroundTransparency = 1
	label.BorderSizePixel = 0
	label.TextXAlignment = Enum.TextXAlignment.Left
	return {root = root, swatch = swatch, label = label, info = nil}
end

function updateColorPage()
	local colors = getFilteredBrickColors()
	local maxPage = getMaxPage(#colors)
	if colorPage > maxPage then
		colorPage = maxPage
	end
	if colorPage < 1 then
		colorPage = 1
	end

	for i = 1, #colorRows do
		local colorIndex = ((colorPage - 1) * ROWS_PER_PAGE) + i
		local row = colorRows[i]
		local info = colors[colorIndex]
		row.info = info
		if info then
			row.root.Visible = activeTab == "colors"
			row.swatch.BackgroundColor3 = info.color
			row.label.Text = info.name .. " (" .. tostring(info.number) .. ")"
		else
			row.root.Visible = false
			row.label.Text = ""
		end
	end
	if #colors == 0 then
		colorPageLabel.Text = "No matches"
	else
		colorPageLabel.Text = "Page " .. tostring(colorPage) .. "/" .. tostring(maxPage)
	end
end

local function refreshPaletteRows()
	local parts = getPaletteScanParts()
	local byNumber = {}
	local total = #parts

	for i = 1, #parts do
		local info = makeBrickColorInfo(parts[i].BrickColor)
		local row = byNumber[info.number]
		if row then
			row.count = row.count + 1
		else
			row = {
				info = info,
				count = 1
			}
			byNumber[info.number] = row
			table.insert(paletteRows, row)
		end
	end

	table.sort(paletteRows, function(first, second)
		if first.count == second.count then
			return first.info.number < second.info.number
		end
		return first.count > second.count
	end)

	for i = 1, #paletteRows do
		if total > 0 then
			paletteRows[i].percent = (paletteRows[i].count / total) * 100
		else
			paletteRows[i].percent = 0
		end
	end
end

function updatePalettePage()
	local maxPage = getMaxPage(#paletteRows)
	if palettePage > maxPage then
		palettePage = maxPage
	end
	if palettePage < 1 then
		palettePage = 1
	end

	for i = 1, #usageRows do
		local rowIndex = ((palettePage - 1) * ROWS_PER_PAGE) + i
		local usage = paletteRows[rowIndex]
		local row = usageRows[i]
		if usage then
			row.info = usage.info
			row.root.Visible = activeTab == "palette"
			row.swatch.BackgroundColor3 = usage.info.color
			row.label.Text = usage.info.name .. " (" .. tostring(usage.info.number) .. ") - " .. tostring(usage.count) .. " - " .. string.format("%.1f%%", usage.percent)
		else
			row.info = nil
			row.root.Visible = false
			row.label.Text = ""
		end
	end
	palettePageLabel.Text = "Page " .. tostring(palettePage) .. "/" .. tostring(maxPage)
end

function refreshPalette()
	paletteRows = {}
	palettePage = 1
	refreshPaletteRows()
	updatePalettePage()
end

local function setPanelVisible(visible)
	if panel then
		panel.Visible = visible
	end
	if visible then
		if #paletteRows == 0 then
			refreshPalette()
		end
		updateColorPage()
		updatePalettePage()
	end
	refreshButtonStates()
end

local function makeCloseButton(parent)
	local button = makeButton(parent, "X", 336, 6, 18, 18)
	button.BackgroundColor3 = Color3.new(0.14, 0.14, 0.14)
	button.MouseButton1Down:connect(function()
		setPanelVisible(false)
	end)
	button.MouseButton1Click:connect(function()
		setPanelVisible(false)
	end)
end

local function makeGui()
	gui = Instance.new("ScreenGui")
	gui.Name = "ProtoAnoBigGlovePalette"
	gui.Parent = CoreGui

	panel = Instance.new("Frame")
	panel.Name = "PaletteTools"
	panel.BackgroundColor3 = colorFromHex(GUI_BACKGROUND_HEX)
	panel.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	panel.Position = UDim2.new(0, 12, 0, 72)
	panel.Size = PANEL_SIZE
	panel.Visible = false
	pcall(function()
		panel.Active = true
		panel.Draggable = true
		panel.ClipsDescendants = true
	end)
	panel.Parent = gui

	local title = makeText(panel, PLUGIN_NAME, 8, 6, 250, 22)
	title.FontSize = Enum.FontSize.Size18
	makeCloseButton(panel)

	tabButtons.colors = makeButton(panel, "Colors", 8, 32, 74, 22)
	tabButtons.palette = makeButton(panel, "Palette", 86, 32, 74, 22)
	tabButtons.colors.MouseButton1Click:connect(function()
		setTab("colors")
	end)
	tabButtons.palette.MouseButton1Click:connect(function()
		setTab("palette")
	end)
	local searchLabel = makeText(panel, "Search", 164, 36, 42, 18)
	searchBox = Instance.new("TextBox")
	searchBox.BackgroundColor3 = Color3.new(0.08, 0.08, 0.08)
	searchBox.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	searchBox.ClearTextOnFocus = false
	searchBox.Font = Enum.Font.ArialBold
	searchBox.FontSize = Enum.FontSize.Size12
	searchBox.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	searchBox.Text = ""
	searchBox.Position = UDim2.new(0, 208, 0, 32)
	searchBox.Size = UDim2.new(0, 62, 0, 22)
	searchBox.Parent = panel

	for i = 1, ROWS_PER_PAGE do
		colorRows[i] = makeColorRow(panel, i)
		local colorRow = colorRows[i]
		colorRow.swatch.MouseButton1Click:connect(function()
			if colorRow.info then
				paintSelection(colorRow.info)
			end
		end)
		colorRow.label.MouseButton1Click:connect(function()
			if colorRow.info then
				paintSelection(colorRow.info)
			end
		end)
		usageRows[i] = makeUsageRow(panel, i)
		local usageRow = usageRows[i]
		usageRow.swatch.MouseButton1Click:connect(function()
			if usageRow.info then
				paintSelection(usageRow.info)
			end
		end)
		usageRow.label.MouseButton1Click:connect(function()
			if usageRow.info then
				paintSelection(usageRow.info)
			end
		end)
	end

	local leftColor = makeButton(panel, "<", 8, 218, 30, 22)
	colorPageLabel = makeText(panel, "", 44, 221, 86, 18)
	local rightColor = makeButton(panel, ">", 132, 218, 30, 22)
	local leftPalette = makeButton(panel, "<", 8, 218, 30, 22)
	palettePageLabel = makeText(panel, "", 44, 221, 86, 18)
	local rightPalette = makeButton(panel, ">", 132, 218, 30, 22)
	local randomize = makeButton(panel, "Randomize", 184, 218, 84, 22)
	local refresh = makeButton(panel, "Refresh", 272, 218, 74, 22)
	colorControls = {searchLabel, searchBox, leftColor, colorPageLabel, rightColor}
	paletteControls = {leftPalette, palettePageLabel, rightPalette, refresh}

	searchBox.FocusLost:connect(function()
		colorPage = 1
		updateColorPage()
	end)
	searchBox.Changed:connect(function(property)
		if not property or property == "Text" then
			colorPage = 1
			updateColorPage()
		end
	end)

	leftColor.MouseButton1Click:connect(function()
		colorPage = colorPage - 1
		updateColorPage()
	end)
	rightColor.MouseButton1Click:connect(function()
		colorPage = colorPage + 1
		updateColorPage()
	end)
	leftPalette.MouseButton1Click:connect(function()
		palettePage = palettePage - 1
		updatePalettePage()
	end)
	rightPalette.MouseButton1Click:connect(function()
		palettePage = palettePage + 1
		updatePalettePage()
	end)
	randomize.MouseButton1Click:connect(randomizeSelection)
	refresh.MouseButton1Click:connect(refreshPalette)

	setTab("colors")
end

makeGui()

showButton.Click:connect(function()
	setPanelVisible(not panel.Visible)
end)

plugin.Deactivation:connect(function()
	refreshButtonStates()
end)
