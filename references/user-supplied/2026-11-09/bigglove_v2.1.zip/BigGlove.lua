-- FOR ONLYRETROROBLOXHERE USERS:
-- Your path is your ORRH folder -> data\clients\<ver#>\MFCStudio\BuiltInPlugins.
-- If MFCStudio isn't there yet, you haven't opened Studio with that version before.
-- Or... you have, and it's named differently for some reason.
-- Look for RobloxStudio.exe in the recesses of a ver#'s client. There should be a BuiltInPlugins folder somewhere.

local PLUGIN_NAME = "ProtoAno's BigGlove"
local TOOLBAR_NAME = "ProtoAno's BigGlove"

-- Theme Editor (i guess)
local GUI_BACKGROUND_HEX = "#8DB83E"
local GUI_BORDER_HEX = "#737373"
local GUI_TEXT_HEX = "#FFFFFF"

local TOOL_PANEL_SIZE = UDim2.new(0, 236, 0, 213)
local ACKNOWLEDGMENT_PANEL_SIZE = UDim2.new(0, 320, 0, 208)

plugin = PluginManager():CreatePlugin()

local Selection = game:GetService("Selection")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local CoreGui = game:GetService("CoreGui")

local toolbar = plugin:CreateToolbar(TOOLBAR_NAME)
local showButton = toolbar:CreateButton("Basic", "Show " .. PLUGIN_NAME, "bigglove_main.png")

local DEBUG_BIG_GLOVE = false

local activeMode = nil
local dragging = false
local pluginMouseActive = false
local collectiveMovement = false
local symmetricResize = false
local globalRotation = false
local originals = {}
local moveReferenceCFrame = nil
local rotateReferenceCFrame = nil
local activeParts = {}
local moveHandles = nil
local moveProxy = nil
local resizeHandles = nil
local rotateHandles = nil
local rotateProxy = nil
local gui = nil
local panel = nil
local acknowledgmentPanel = nil
local toolButtons = {}
local incrementBoxes = {}
local transformPartStates = nil
local setPanelVisible = nil
local refreshButtonStates = nil
local finishDrag = nil

local increments = {
	move = 1,
	rotate = 15,
	resize = 1
}

local function debugPrint(...)
	if not DEBUG_BIG_GLOVE then
		return
	end
	local chunks = {"[BigGlove DEBUG]"}
	for i = 1, select("#", ...) do
		table.insert(chunks, tostring(select(i, ...)))
	end
	print(table.concat(chunks, " "))
end

local function describePart(part)
	if not part then
		return "nil"
	end
	local ok, description = pcall(function()
		return part:GetFullName() .. " pos=" .. tostring(part.CFrame.p) .. " size=" .. tostring(part.Size)
	end)
	if ok then
		return description
	end
	return tostring(part)
end

local function describeSelection()
	local selected = Selection:Get()
	local chunks = {}
	for i = 1, #selected do
		table.insert(chunks, selected[i]:GetFullName())
	end
	if #chunks == 0 then
		return "none"
	end
	return table.concat(chunks, ", ")
end

local normalVectors = {
	[Enum.NormalId.Right] = Vector3.new(1, 0, 0),
	[Enum.NormalId.Left] = Vector3.new(-1, 0, 0),
	[Enum.NormalId.Top] = Vector3.new(0, 1, 0),
	[Enum.NormalId.Bottom] = Vector3.new(0, -1, 0),
	[Enum.NormalId.Back] = Vector3.new(0, 0, 1),
	[Enum.NormalId.Front] = Vector3.new(0, 0, -1)
}

local axisVectors = {
	[Enum.Axis.X] = Vector3.new(1, 0, 0),
	[Enum.Axis.Y] = Vector3.new(0, 1, 0),
	[Enum.Axis.Z] = Vector3.new(0, 0, 1)
}

local function roundToStep(value, step)
	if step == 0 then
		return value
	end
	if value >= 0 then
		return math.floor((value / step) + 0.5) * step
	end
	return math.ceil((value / step) - 0.5) * step
end

local function clamp(value, low, high)
	if value < low then
		return low
	end
	if value > high then
		return high
	end
	return value
end

local function vectorX(vector)
	return vector.x or vector.X or 0
end

local function vectorY(vector)
	return vector.y or vector.Y or 0
end

local function vectorZ(vector)
	return vector.z or vector.Z or 0
end

local function localVectorToWorld(cframe, vector)
	local ok, result = pcall(function()
		return cframe:vectorToWorldSpace(vector)
	end)
	if ok then
		return result
	end
	return vector
end

local function dotVector(first, second)
	return (vectorX(first) * vectorX(second)) + (vectorY(first) * vectorY(second)) + (vectorZ(first) * vectorZ(second))
end

local function makeTranslation(vector)
	return CFrame.new(vectorX(vector), vectorY(vector), vectorZ(vector))
end

local function translateCFrame(cframe, offset)
	return makeTranslation(offset) * cframe
end

local function colorFromHex(hex)
	hex = string.gsub(hex, "#", "")
	return Color3.new(
		tonumber(string.sub(hex, 1, 2), 16) / 255,
		tonumber(string.sub(hex, 3, 4), 16) / 255,
		tonumber(string.sub(hex, 5, 6), 16) / 255
	)
end

local function collectParts(object, parts)
	if object:IsA("BasePart") then
		table.insert(parts, object)
	end

	local children = object:GetChildren()
	for i = 1, #children do
		collectParts(children[i], parts)
	end
end

local function isAncestorOf(ancestor, object)
	object = object.Parent
	while object do
		if object == ancestor then
			return true
		end
		object = object.Parent
	end
	return false
end

local function getSelectedRoots()
	local roots = {}
	local selected = Selection:Get()

	for i = 1, #selected do
		if selected[i]:IsA("BasePart") or selected[i]:IsA("Model") then
			local nested = false
			for j = 1, #selected do
				if i ~= j and selected[j]:IsA("Model") and isAncestorOf(selected[j], selected[i]) then
					nested = true
					break
				end
			end
			if not nested then
				table.insert(roots, selected[i])
			end
		end
	end

	return roots
end

local function getSelectedParts()
	local parts = {}
	local roots = getSelectedRoots()

	for i = 1, #roots do
		collectParts(roots[i], parts)
	end

	debugPrint("getSelectedParts roots=", #roots, "baseParts=", #parts, "selection=", describeSelection())
	return parts
end

local function getPrimaryPart(model)
	local ok, primaryPart = pcall(function()
		return model.PrimaryPart
	end)
	if ok and primaryPart and primaryPart:IsA("BasePart") then
		return primaryPart
	end
	return nil
end

local function getPartsCenter(parts)
	if #parts == 0 then
		return Vector3.new(0, 0, 0)
	end

	local total = Vector3.new(0, 0, 0)
	for i = 1, #parts do
		total = total + parts[i].CFrame.p
	end
	return total / #parts
end

local function replaceCFramePosition(cframe, position)
	local ok, result = pcall(function()
		return CFrame.new(position) * (cframe - cframe.p)
	end)
	if ok then
		return result
	end
	return CFrame.new(position)
end

local function getPartsBoundsCenter(parts, referenceCFrame)
	if #parts == 0 then
		return referenceCFrame.p
	end

	local xAxis = localVectorToWorld(referenceCFrame, Vector3.new(1, 0, 0))
	local yAxis = localVectorToWorld(referenceCFrame, Vector3.new(0, 1, 0))
	local zAxis = localVectorToWorld(referenceCFrame, Vector3.new(0, 0, 1))
	local axes = {xAxis, yAxis, zAxis}
	local lows = {nil, nil, nil}
	local highs = {nil, nil, nil}

	for i = 1, #parts do
		local part = parts[i]
		local center = part.CFrame.p
		local localAxes = {
			localVectorToWorld(part.CFrame, Vector3.new(1, 0, 0)),
			localVectorToWorld(part.CFrame, Vector3.new(0, 1, 0)),
			localVectorToWorld(part.CFrame, Vector3.new(0, 0, 1))
		}
		local sizes = {vectorX(part.Size), vectorY(part.Size), vectorZ(part.Size)}

		for axisIndex = 1, 3 do
			local axis = axes[axisIndex]
			local halfExtent = 0
			for localAxisIndex = 1, 3 do
				halfExtent = halfExtent + (math.abs(dotVector(localAxes[localAxisIndex], axis)) * sizes[localAxisIndex] / 2)
			end

			local coordinate = dotVector(center, axis)
			local low = coordinate - halfExtent
			local high = coordinate + halfExtent
			if not lows[axisIndex] or low < lows[axisIndex] then
				lows[axisIndex] = low
			end
			if not highs[axisIndex] or high > highs[axisIndex] then
				highs[axisIndex] = high
			end
		end
	end

	return (xAxis * (((lows[1] or 0) + (highs[1] or 0)) / 2)) +
		(yAxis * (((lows[2] or 0) + (highs[2] or 0)) / 2)) +
		(zAxis * (((lows[3] or 0) + (highs[3] or 0)) / 2))
end

local function getPartsBoundsReferenceCFrame(parts, referenceCFrame)
	return replaceCFramePosition(referenceCFrame, getPartsBoundsCenter(parts, referenceCFrame))
end

local function getCollectiveMoveReferenceCFrame()
	local roots = getSelectedRoots()
	if #roots == 1 then
		if roots[1]:IsA("BasePart") then
			return roots[1].CFrame
		elseif roots[1]:IsA("Model") then
			local primaryPart = getPrimaryPart(roots[1])
			local modelParts = {}
			collectParts(roots[1], modelParts)
			if primaryPart then
				return getPartsBoundsReferenceCFrame(modelParts, primaryPart.CFrame)
			end
			return getPartsBoundsReferenceCFrame(modelParts, CFrame.new(getPartsCenter(modelParts)))
		end
	end

	local parts = {}
	for i = 1, #roots do
		if roots[i]:IsA("BasePart") then
			table.insert(parts, roots[i])
		elseif roots[i]:IsA("Model") then
			local primaryPart = getPrimaryPart(roots[i])
			if primaryPart then
				table.insert(parts, primaryPart)
			else
				collectParts(roots[i], parts)
			end
		end
	end

	if #parts == 1 then
		return parts[1].CFrame
	end
	return getPartsBoundsReferenceCFrame(parts, CFrame.new(getPartsCenter(parts)))
end

local function getAdornee()
	activeParts = getSelectedParts()
	if #activeParts > 0 then
		debugPrint("getAdornee ->", describePart(activeParts[1]))
		return activeParts[1]
	end
	debugPrint("getAdornee -> nil")
	return nil
end

local function rememberOriginals()
	originals = {}
	activeParts = getSelectedParts()

	for i = 1, #activeParts do
		originals[activeParts[i]] = {
			cframe = activeParts[i].CFrame,
			size = activeParts[i].Size
		}
	end
	debugPrint("rememberOriginals count=", #activeParts, "mode=", activeMode)
end

local function cframeInverse(cframe)
	local ok, result = pcall(function()
		return cframe:inverse()
	end)
	if ok then
		return result
	end
	return cframe:Inverse()
end

local function getReferenceAxis(referenceCFrame, vector)
	return localVectorToWorld(referenceCFrame, vector)
end

local function getSelectionProxySize(referenceCFrame)
	if #activeParts == 0 then
		return Vector3.new(1, 1, 1)
	end

	local xAxis = getReferenceAxis(referenceCFrame, Vector3.new(1, 0, 0))
	local yAxis = getReferenceAxis(referenceCFrame, Vector3.new(0, 1, 0))
	local zAxis = getReferenceAxis(referenceCFrame, Vector3.new(0, 0, 1))
	local axes = {xAxis, yAxis, zAxis}
	local lows = {nil, nil, nil}
	local highs = {nil, nil, nil}

	for i = 1, #activeParts do
		local part = activeParts[i]
		local center = part.CFrame.p
		local localAxes = {
			localVectorToWorld(part.CFrame, Vector3.new(1, 0, 0)),
			localVectorToWorld(part.CFrame, Vector3.new(0, 1, 0)),
			localVectorToWorld(part.CFrame, Vector3.new(0, 0, 1))
		}
		local sizes = {vectorX(part.Size), vectorY(part.Size), vectorZ(part.Size)}

		for axisIndex = 1, 3 do
			local axis = axes[axisIndex]
			local halfExtent = 0
			for localAxisIndex = 1, 3 do
				halfExtent = halfExtent + (math.abs(dotVector(localAxes[localAxisIndex], axis)) * sizes[localAxisIndex] / 2)
			end

			local coordinate = dotVector(center, axis)
			local low = coordinate - halfExtent
			local high = coordinate + halfExtent
			if not lows[axisIndex] or low < lows[axisIndex] then
				lows[axisIndex] = low
			end
			if not highs[axisIndex] or high > highs[axisIndex] then
				highs[axisIndex] = high
			end
		end
	end

	return Vector3.new(
		math.max((highs[1] or 1) - (lows[1] or 0), 0.2),
		math.max((highs[2] or 1) - (lows[2] or 0), 0.2),
		math.max((highs[3] or 1) - (lows[3] or 0), 0.2)
	)
end

local function positionsClose(first, second)
	local delta = first - second
	return math.abs(vectorX(delta)) < 0.0005 and math.abs(vectorY(delta)) < 0.0005 and math.abs(vectorZ(delta)) < 0.0005
end

local function cframesClose(first, second)
	if not positionsClose(first.p, second.p) then
		return false
	end
	local ok, result = pcall(function()
		return positionsClose(first.lookVector, second.lookVector)
	end)
	if ok then
		return result
	end
	return true
end

local function beginTransformPartStates(parts, freeSize)
	transformPartStates = {}
	for i = 1, #parts do
		local part = parts[i]
		local state = {
			part = part,
			anchored = part.Anchored,
			canCollide = part.CanCollide,
			locked = part.Locked,
			restoreFormFactor = not freeSize
		}
		pcall(function()
			state.formFactor = part.FormFactor
		end)
		table.insert(transformPartStates, state)

		part.Anchored = true
		part.CanCollide = false
		part.Locked = false
		if freeSize then
			pcall(function()
				part.FormFactor = Enum.FormFactor.Custom
			end)
		end
	end
end

local function finishTransformPartStates()
	if not transformPartStates then
		return
	end
	for i = 1, #transformPartStates do
		local state = transformPartStates[i]
		if state.part and state.part.Parent then
			if state.restoreFormFactor and state.formFactor then
				pcall(function()
					state.part.FormFactor = state.formFactor
				end)
			end
			state.part.Anchored = state.anchored
			state.part.CanCollide = state.canCollide
			state.part.Locked = state.locked
		end
	end
	transformPartStates = nil
end

local function setPartCFrame(part, cframe, label)
	local before = part.CFrame
	local ok, message = pcall(function()
		part.CFrame = cframe
	end)
	if not ok then
		debugPrint(label, "CFrame write failed", describePart(part), "error=", message)
		return false
	end
	local after = part.CFrame
	if not cframesClose(after, cframe) then
		pcall(function()
			part.Position = cframe.p
		end)
		after = part.CFrame
	end
	debugPrint(label, "CFrame write ok before=", tostring(before.p), "target=", tostring(cframe.p), "after=", tostring(after.p))
	return cframesClose(after, cframe)
end

local function setPartSize(part, size, label)
	local before = part.Size
	local ok, message = pcall(function()
		part.Size = size
	end)
	if not ok then
		debugPrint(label, "Size write failed", describePart(part), "error=", message)
		return false
	end
	local after = part.Size
	debugPrint(label, "Size write ok before=", tostring(before), "target=", tostring(size), "after=", tostring(after))
	return true
end

local function saveIncrement(key)
	local box = incrementBoxes[key]
	if box then
		local value = tonumber(box.Text)
		if value and value > 0 then
			increments[key] = value
		end
		box.Text = tostring(increments[key])
		debugPrint("saveIncrement", key, "value=", increments[key])
	end
end

local function saveAllIncrements()
	saveIncrement("move")
	saveIncrement("rotate")
	saveIncrement("resize")
end

local function restoreSelection(parts)
	if parts and #parts > 0 then
		debugPrint("restoreSelection count=", #parts)
		pcall(function()
			Selection:Set(parts)
		end)
	else
		debugPrint("restoreSelection skipped")
	end
end

local function getSelectionToRestore()
	local roots = getSelectedRoots()
	if #roots > 0 then
		return roots
	end
	return activeParts
end

local function setButtonActive(button, active)
	if active then
		button.BackgroundColor3 = Color3.new(0.18, 0.36, 0.72)
		button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	else
		button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
		button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	end
end

local function setAdornees()
	local adornee = getAdornee()
	debugPrint("setAdornees mode=", activeMode, "adornee=", describePart(adornee), "collectiveMovement=", collectiveMovement, "globalRotation=", globalRotation)
	moveHandles.Adornee = nil
	resizeHandles.Adornee = nil
	rotateHandles.Adornee = nil
	if moveProxy then
		moveProxy.Parent = nil
	end
	if rotateProxy then
		rotateProxy.Parent = nil
	end

	if activeMode == "move" then
		if collectiveMovement and adornee and moveProxy then
			moveProxy.CFrame = getCollectiveMoveReferenceCFrame()
			moveProxy.Size = getSelectionProxySize(moveProxy.CFrame)
			moveProxy.Parent = game.Workspace
			moveHandles.Adornee = moveProxy
		else
			moveHandles.Adornee = adornee
		end
	elseif activeMode == "resize" then
		resizeHandles.Adornee = adornee
	elseif activeMode == "rotate" then
		if collectiveMovement and adornee and rotateProxy then
			rotateProxy.CFrame = getCollectiveMoveReferenceCFrame()
			if globalRotation then
				rotateProxy.CFrame = CFrame.new(rotateProxy.CFrame.p)
			end
			rotateProxy.Size = getSelectionProxySize(rotateProxy.CFrame)
			rotateProxy.Parent = game.Workspace
			rotateHandles.Adornee = rotateProxy
		elseif globalRotation and adornee and rotateProxy then
			rotateProxy.Size = adornee.Size
			rotateProxy.CFrame = CFrame.new(adornee.CFrame.p)
			rotateProxy.Parent = game.Workspace
			rotateHandles.Adornee = rotateProxy
		else
			rotateHandles.Adornee = adornee
		end
	end
	debugPrint("setAdornees done move=", tostring(moveHandles.Adornee), "resize=", tostring(resizeHandles.Adornee), "rotate=", tostring(rotateHandles.Adornee))
end

local function clearHandles()
	debugPrint("clearHandles mode=", activeMode)
	if moveHandles then
		moveHandles.Adornee = nil
	end
	if moveProxy then
		moveProxy.Parent = nil
	end
	if resizeHandles then
		resizeHandles.Adornee = nil
	end
	if rotateHandles then
		rotateHandles.Adornee = nil
	end
	if rotateProxy then
		rotateProxy.Parent = nil
	end
end

local function refreshCurrentHandles(partsToReselect)
	debugPrint("refreshCurrentHandles count=", partsToReselect and #partsToReselect or 0)
	clearHandles()
	restoreSelection(partsToReselect)
	setAdornees()
	refreshButtonStates()
end

local function hideTools()
	debugPrint("hideTools activeMode=", activeMode, "dragging=", dragging)
	local partsToReselect = getSelectionToRestore()

	finishDrag()
	activeMode = nil
	dragging = false
	originals = {}
	clearHandles()
	restoreSelection(partsToReselect)
	refreshButtonStates()
end

local function activatePluginMouse()
	if not pluginMouseActive then
		debugPrint("plugin Activate true")
		plugin:Activate(true)
		pluginMouseActive = true
	else
		debugPrint("plugin Activate skipped already active")
	end
end

function refreshButtonStates()
	debugPrint("refreshButtonStates activeMode=", activeMode, "panelVisible=", panel and panel.Visible)
	local key, button
	for key, button in pairs(toolButtons) do
		setButtonActive(button, key == activeMode)
	end
	pcall(function()
		showButton:SetActive(panel and panel.Visible)
	end)
end

function finishDrag()
	debugPrint("finishDrag dragging=", dragging, "activeMode=", activeMode)
	if dragging then
		ChangeHistoryService:SetWaypoint(PLUGIN_NAME .. " " .. activeMode)
		debugPrint("waypoint set", PLUGIN_NAME .. " " .. tostring(activeMode))
	end
	dragging = false
	originals = {}
	moveReferenceCFrame = nil
	rotateReferenceCFrame = nil
	finishTransformPartStates()
	setAdornees()
end

local function setMode(mode)
	debugPrint("setMode requested=", mode, "current=", activeMode, "dragging=", dragging)
	saveAllIncrements()
	local partsToReselect = getSelectionToRestore()
	debugPrint("setMode partsToReselect=", partsToReselect and #partsToReselect or 0)

	if activeMode == mode then
		debugPrint("setMode toggling off", mode)
		if dragging then
			finishDrag()
		end
		activeMode = nil
		clearHandles()
		restoreSelection(partsToReselect)
	else
		debugPrint("setMode toggling on", mode)
		if dragging then
			finishDrag()
		end
		clearHandles()
		activeMode = mode
		activatePluginMouse()
		restoreSelection(partsToReselect)
		setAdornees()
	end

	debugPrint("setMode complete activeMode=", activeMode)
	refreshButtonStates()
end

function setPanelVisible(visible)
	debugPrint("setPanelVisible", visible)
	if panel then
		panel.Visible = visible
	end
	refreshButtonStates()
end

local function makeText(parent, text, x, y, w, h)
	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.BorderSizePixel = 0
	label.Font = Enum.Font.Arial
	label.FontSize = Enum.FontSize.Size12
	label.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Text = text
	label.Position = UDim2.new(0, x, 0, y)
	label.Size = UDim2.new(0, w, 0, h)
	label.Parent = parent
	return label
end

local function makeButton(parent, key, text, x, y)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = text
	button.Position = UDim2.new(0, x, 0, y)
	button.Size = UDim2.new(0, 62, 0, 24)
	button.Parent = parent
	button.MouseButton1Click:connect(function()
		debugPrint("button click", key)
		setMode(key)
	end)
	toolButtons[key] = button
	return button
end

local function makeBox(parent, key, x, y)
	local box = Instance.new("TextBox")
	box.BackgroundColor3 = Color3.new(0.08, 0.08, 0.08)
	box.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	box.ClearTextOnFocus = false
	box.Font = Enum.Font.ArialBold
	box.FontSize = Enum.FontSize.Size12
	box.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	box.Text = tostring(increments[key])
	box.Position = UDim2.new(0, x, 0, y)
	box.Size = UDim2.new(0, 54, 0, 22)
	box.Parent = parent
	box.FocusLost:connect(function()
		debugPrint("box FocusLost", key, "text=", box.Text)
		saveIncrement(key)
	end)
	incrementBoxes[key] = box
	return box
end

local function makeCheckbox(parent, text, x, y, initialValue, onChanged)
	local checked = initialValue
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	if checked then
		button.Text = "[X]"
	else
		button.Text = "[ ]"
	end
	button.Position = UDim2.new(0, x, 0, y)
	button.Size = UDim2.new(0, 28, 0, 20)
	button.Parent = parent

	makeText(parent, text, x + 34, y + 1, 140, 18)

	button.MouseButton1Click:connect(function()
		checked = not checked
		debugPrint("checkbox", text, "checked=", checked)
		if checked then
			button.Text = "[X]"
		else
			button.Text = "[ ]"
		end
		onChanged(checked)
	end)

	return button
end

local function getTransformationModeText()
	if collectiveMovement then
		return "Collective"
	end
	return "Individual"
end

local function makeTransformationModeButton(parent, x, y)
	makeText(parent, "Transformation Mode", x, y + 2, 120, 18)

	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = getTransformationModeText()
	button.Position = UDim2.new(0, x + 124, 0, y)
	button.Size = UDim2.new(0, 82, 0, 22)
	button.Parent = parent

	button.MouseButton1Click:connect(function()
		local partsToReselect = getSelectionToRestore()

		collectiveMovement = not collectiveMovement
		button.Text = getTransformationModeText()
		if activeMode == "move" or activeMode == "rotate" then
			if dragging then
				finishDrag()
			end
			refreshCurrentHandles(partsToReselect)
		end
	end)

	return button
end

local function makeWrappedText(parent, text, x, y, w, h, color)
	local label = makeText(parent, text, x, y, w, h)
	label.TextColor3 = color
	label.TextYAlignment = Enum.TextYAlignment.Top
	label.TextWrap = true
	return label
end

local function makeAcknowledgment(parent)
	acknowledgmentPanel = Instance.new("Frame")
	acknowledgmentPanel.Name = "Acknowledgment"
	acknowledgmentPanel.BackgroundColor3 = colorFromHex(GUI_BACKGROUND_HEX)
	acknowledgmentPanel.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	acknowledgmentPanel.Position = UDim2.new(0, 0, 0, 0)
	acknowledgmentPanel.Size = UDim2.new(1, 0, 1, 0)
	acknowledgmentPanel.Parent = parent

	makeWrappedText(
		acknowledgmentPanel,
		"hi, if you're reading this, thanks for trying this out. this was mainly an experiment for me in seeing if i could help out the roblox webseries community in my own stupid little way.",
		10,
		10,
		300,
		58,
		colorFromHex(GUI_TEXT_HEX)
	)

	local warning = makeText(acknowledgmentPanel, "be careful when using this plug-in", 10, 70, 300, 18)
	warning.TextColor3 = Color3.new(1, 0, 0)
	warning.Font = Enum.Font.ArialBold

	makeWrappedText(
		acknowledgmentPanel,
		"older roblox clients hate when you spam-switch between items. you'll probably have to refresh it on the actual hotbar if you flip-flop without your own restraint.",
		10,
		94,
		300,
		46,
		colorFromHex(GUI_TEXT_HEX)
	)

	makeText(acknowledgmentPanel, "cheers, ProtoAno", 10, 146, 300, 18)

	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.18, 0.18, 0.18)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = "i get it, show me the tools"
	button.Position = UDim2.new(0, 10, 0, 174)
	button.Size = UDim2.new(0, 185, 0, 24)
	button.Parent = acknowledgmentPanel
	button.MouseButton1Click:connect(function()
		debugPrint("acknowledgment dismissed")
		acknowledgmentPanel.Visible = false
		panel.Size = TOOL_PANEL_SIZE
	end)
end

local function makeCloseButton(parent)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = Color3.new(0.14, 0.14, 0.14)
	button.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	button.Font = Enum.Font.ArialBold
	button.FontSize = Enum.FontSize.Size12
	button.TextColor3 = colorFromHex(GUI_TEXT_HEX)
	button.Text = "X"
	button.Position = UDim2.new(1, -24, 0, 6)
	button.Size = UDim2.new(0, 18, 0, 18)
	button.Parent = parent
	button.MouseButton1Down:connect(hideTools)
	button.MouseButton1Click:connect(hideTools)
	return button
end

local function makeGui()
	debugPrint("makeGui")
	gui = Instance.new("ScreenGui")
	gui.Name = "ProtoAnoBigGlove"
	gui.Parent = CoreGui

	panel = Instance.new("Frame")
	panel.Name = "TransformTools"
	panel.BackgroundColor3 = colorFromHex(GUI_BACKGROUND_HEX)
	panel.BorderColor3 = colorFromHex(GUI_BORDER_HEX)
	panel.Position = UDim2.new(0, 12, 0, 72)
	panel.Size = ACKNOWLEDGMENT_PANEL_SIZE
	panel.Visible = true
	pcall(function()
		panel.Active = true
		panel.Draggable = true
	end)
	panel.Parent = gui

	local title = makeText(panel, PLUGIN_NAME, 8, 6, 190, 22)
	title.FontSize = Enum.FontSize.Size18
	makeCloseButton(panel)
	makeText(panel, "Tool", 8, 31, 64, 18)
	makeText(panel, "Increment", 142, 31, 74, 18)

	makeButton(panel, "move", "Move", 8, 51)
	makeButton(panel, "rotate", "Rotate", 8, 78)
	makeButton(panel, "resize", "Resize", 8, 129)

	makeText(panel, "studs", 74, 54, 52, 18)
	makeText(panel, "degrees", 74, 81, 58, 18)
	makeText(panel, "studs", 74, 132, 52, 18)

	makeBox(panel, "move", 150, 52)
	makeBox(panel, "rotate", 150, 79)
	makeBox(panel, "resize", 150, 130)
	makeCheckbox(panel, "Global Rotation", 8, 105, globalRotation, function(value)
		local partsToReselect = getSelectionToRestore()

		globalRotation = value
		if activeMode == "rotate" then
			if dragging then
				finishDrag()
			end
			refreshCurrentHandles(partsToReselect)
		end
	end)
	makeCheckbox(panel, "Symmetric Resize", 8, 156, symmetricResize, function(value)
		symmetricResize = value
	end)
	makeTransformationModeButton(panel, 8, 183)
	makeAcknowledgment(panel)
end

local function makeHandles()
	debugPrint("makeHandles")
	moveHandles = Instance.new("Handles")
	moveHandles.Name = "ProtoAnoMoveHandles"
	moveHandles.Color = BrickColor.new("Bright blue")
	moveHandles.Style = Enum.HandlesStyle.Movement
	moveHandles.Parent = CoreGui

	moveProxy = Instance.new("Part")
	moveProxy.Name = "ProtoAnoCollectiveMoveProxy"
	moveProxy.Archivable = false
	moveProxy.Anchored = true
	moveProxy.CanCollide = false
	moveProxy.Locked = true
	moveProxy.Transparency = 1
	pcall(function()
		moveProxy.FormFactor = Enum.FormFactor.Custom
	end)

	resizeHandles = Instance.new("Handles")
	resizeHandles.Name = "ProtoAnoResizeHandles"
	resizeHandles.Color = BrickColor.new("Bright green")
	resizeHandles.Style = Enum.HandlesStyle.Resize
	resizeHandles.Parent = CoreGui

	rotateHandles = Instance.new("ArcHandles")
	rotateHandles.Name = "ProtoAnoRotateHandles"
	rotateHandles.Color = BrickColor.new("Bright orange")
	rotateHandles.Parent = CoreGui

	rotateProxy = Instance.new("Part")
	rotateProxy.Name = "ProtoAnoGlobalRotateProxy"
	rotateProxy.Archivable = false
	rotateProxy.Anchored = true
	rotateProxy.CanCollide = false
	rotateProxy.Locked = true
	rotateProxy.Transparency = 1
	pcall(function()
		rotateProxy.FormFactor = Enum.FormFactor.Custom
	end)

	moveHandles.MouseButton1Down:connect(function()
		debugPrint("move MouseButton1Down selection=", describeSelection(), "collective=", collectiveMovement)
		saveIncrement("move")
		rememberOriginals()
		if collectiveMovement then
			moveReferenceCFrame = getCollectiveMoveReferenceCFrame()
		else
			moveReferenceCFrame = nil
		end
		beginTransformPartStates(activeParts, false)
		dragging = true
		debugPrint("move drag started originals=", #activeParts)
	end)

	moveHandles.MouseDrag:connect(function(face, distance)
		local vector = normalVectors[face]
		if not vector then
			debugPrint("move MouseDrag missing vector face=", tostring(face), "distance=", distance)
			return
		end

		local amount = roundToStep(distance, increments.move)
		debugPrint("move MouseDrag face=", tostring(face), "distance=", distance, "amount=", amount, "collective=", collectiveMovement, "parts=", #activeParts)

		for part, original in pairs(originals) do
			local referenceCFrame = original.cframe
			if collectiveMovement and moveReferenceCFrame then
				referenceCFrame = moveReferenceCFrame
			end
			local offset = localVectorToWorld(referenceCFrame, vector) * amount
			setPartCFrame(part, translateCFrame(original.cframe, offset), "move")
		end
	end)

	moveHandles.MouseButton1Up:connect(finishDrag)

	resizeHandles.MouseButton1Down:connect(function()
		debugPrint("resize MouseButton1Down selection=", describeSelection(), "symmetric=", symmetricResize)
		saveIncrement("resize")
		rememberOriginals()
		beginTransformPartStates(activeParts, true)
		dragging = true
		debugPrint("resize drag started originals=", #activeParts)
	end)

	resizeHandles.MouseDrag:connect(function(face, distance)
		local vector = normalVectors[face]
		if not vector then
			debugPrint("resize MouseDrag missing vector face=", tostring(face), "distance=", distance)
			return
		end

		local amount = roundToStep(distance, increments.resize)
		debugPrint("resize MouseDrag face=", tostring(face), "distance=", distance, "amount=", amount, "symmetric=", symmetricResize, "parts=", #activeParts)

		for part, original in pairs(originals) do
			local absVector = Vector3.new(math.abs(vectorX(vector)), math.abs(vectorY(vector)), math.abs(vectorZ(vector)))
			local sizeDelta = absVector * amount
			if symmetricResize then
				sizeDelta = absVector * (amount * 2)
			end
			local newSize = Vector3.new(
				clamp(vectorX(original.size) + vectorX(sizeDelta), 0.2, 10000),
				clamp(vectorY(original.size) + vectorY(sizeDelta), 0.2, 10000),
				clamp(vectorZ(original.size) + vectorZ(sizeDelta), 0.2, 10000)
			)

			setPartSize(part, newSize, "resize")
			if symmetricResize then
				setPartCFrame(part, original.cframe, "resize symmetric")
			else
				local actualDelta = newSize - original.size
				local localCenterOffset = Vector3.new(
					vectorX(vector) * vectorX(actualDelta) / 2,
					vectorY(vector) * vectorY(actualDelta) / 2,
					vectorZ(vector) * vectorZ(actualDelta) / 2
				)
				local centerOffset = localVectorToWorld(original.cframe, localCenterOffset)
				setPartCFrame(part, translateCFrame(original.cframe, centerOffset), "resize offset")
			end
		end
	end)

	resizeHandles.MouseButton1Up:connect(finishDrag)

	rotateHandles.MouseButton1Down:connect(function()
		debugPrint("rotate MouseButton1Down selection=", describeSelection(), "collective=", collectiveMovement, "global=", globalRotation)
		saveIncrement("rotate")
		rememberOriginals()
		if collectiveMovement then
			rotateReferenceCFrame = getCollectiveMoveReferenceCFrame()
			if globalRotation then
				rotateReferenceCFrame = CFrame.new(rotateReferenceCFrame.p)
			end
		else
			rotateReferenceCFrame = nil
		end
		beginTransformPartStates(activeParts, false)
		dragging = true
		debugPrint("rotate drag started originals=", #activeParts)
	end)

	rotateHandles.MouseDrag:connect(function(axis, relativeAngle)
		local vector = axisVectors[axis]
		if not vector then
			debugPrint("rotate MouseDrag missing vector axis=", tostring(axis), "relativeAngle=", relativeAngle)
			return
		end

		local degrees = roundToStep(math.deg(relativeAngle), increments.rotate)
		debugPrint("rotate MouseDrag axis=", tostring(axis), "relativeAngle=", relativeAngle, "degrees=", degrees, "collective=", collectiveMovement, "global=", globalRotation, "parts=", #activeParts)
		local rotation = CFrame.Angles(
			math.rad(degrees) * vectorX(vector),
			math.rad(degrees) * vectorY(vector),
			math.rad(degrees) * vectorZ(vector)
		)

		for part, original in pairs(originals) do
			if collectiveMovement and rotateReferenceCFrame then
				local transform = rotateReferenceCFrame * rotation * cframeInverse(rotateReferenceCFrame)
				setPartCFrame(part, transform * original.cframe, "rotate collective")
			elseif globalRotation then
				local position = original.cframe.p
				local toOrigin = CFrame.new(-vectorX(position), -vectorY(position), -vectorZ(position))
				local fromOrigin = CFrame.new(vectorX(position), vectorY(position), vectorZ(position))
				setPartCFrame(part, fromOrigin * rotation * toOrigin * original.cframe, "rotate global")
			else
				setPartCFrame(part, original.cframe * rotation, "rotate local")
			end
		end
	end)

	rotateHandles.MouseButton1Up:connect(finishDrag)
end

makeGui()
makeHandles()
setAdornees()
refreshButtonStates()
debugPrint("initialized")

showButton.Click:connect(function()
	debugPrint("toolbar click panelVisible=", panel and panel.Visible)
	setPanelVisible(not panel.Visible)
end)

if Selection.SelectionChanged then
	Selection.SelectionChanged:connect(function()
		debugPrint("SelectionChanged dragging=", dragging, "selection=", describeSelection())
		if not dragging then
			setAdornees()
		end
	end)
end

plugin.Deactivation:connect(function()
	debugPrint("plugin Deactivation")
	pluginMouseActive = false
	activeMode = nil
	finishDrag()
	clearHandles()
	refreshButtonStates()
end)
